#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
鼠鼠偷吃桌面宠物
基于原有的偷吃功能，移植为独立的桌面宠物应用
"""

import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import threading
import time
import random
from datetime import datetime, timedelta
from PIL import Image, ImageTk
import json

# 添加核心模块路径
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'core'))

from pet_game_logic import PetGameLogic
from pet_animation import PetAnimation
from pet_config import PetConfig

# 导入touchi模块用于物品图片生成
try:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'core'))
    from touchi import generate_safe_image, load_items, ITEM_VALUES
except ImportError:
    print("Warning: Could not import touchi module")
    generate_safe_image = None

class DesktopPet:
    def __init__(self, root=None, config=None, data_manager=None, logger=None):
        self.root = root if root else tk.Tk()
        self.config = config if config else PetConfig()
        self.data_manager = data_manager
        self.logger = logger
        self.game_logic = PetGameLogic()
        self.animation = PetAnimation()
        
        # 窗口设置
        self.setup_window()
        
        # 游戏状态
        self.is_playing = False
        self.current_action = "idle"  # idle, stealing, celebrating, sleeping
        self.last_steal_time = None
        self.auto_steal_enabled = False
        self.is_dragging = False
        
        # UI组件
        self.setup_ui()
        
        # 绑定事件
        self.bind_events()
        
        # 启动动画循环
        self.start_animation_loop()
        
        # 启动游戏逻辑循环
        self.start_game_loop()
    
    def setup_window(self):
        """设置窗口属性"""
        self.root.title("鼠鼠偷吃桌面宠物")
        # 主窗口设置为更大尺寸，只显示宠物
        self.root.geometry("200x200")
        
        # 设置窗口置顶
        if self.config.always_on_top:
            self.root.attributes('-topmost', True)
        
        # 设置窗口完全透明背景
        self.root.attributes('-transparentcolor', 'white')
        self.root.configure(bg='white')
        
        # 根据配置决定是否无边框
        if self.config.borderless:
            self.root.overrideredirect(True)  # 无边框窗口
        else:
            # 有边框窗口
            self.root.overrideredirect(False)
            # 设置关闭窗口的协议
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.root.title("桌面宠物 - Touchi")
            # 确保窗口在任务栏显示
            self.root.attributes('-toolwindow', False)
        
        # 侧边栏窗口初始化
        self.sidebar = None
        self.sidebar_visible = False
        
        # 设置窗口图标
        try:
            icon_path = os.path.join(os.path.dirname(__file__), 'icon.ico')
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
        except Exception as e:
            print(f"设置图标失败: {e}")
    
    def setup_ui(self):
        """设置用户界面"""
        # 主窗口只显示宠物动画，背景透明
        self.pet_label = tk.Label(self.root, text="🐭", font=('Arial', 80), 
                                 bg='white', fg='black', cursor='hand2')
        self.pet_label.pack(expand=True, fill='both')
        
        # 右键菜单
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="开始偷吃", command=self.start_stealing)
        self.context_menu.add_command(label="显示/隐藏菜单", command=self.toggle_sidebar)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="设置", command=self.open_settings)
        self.context_menu.add_command(label="退出", command=self.on_closing)
        
        # 初始化侧边栏
        self.setup_sidebar()
    
    def bind_events(self):
        """绑定事件"""
        # 设置关闭事件（如果不是无边框窗口）
        if not self.config.borderless:
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # 绑定事件
        self.pet_label.bind("<Button-1>", self.on_single_click)
        self.pet_label.bind("<B1-Motion>", self.on_drag)
        self.pet_label.bind("<ButtonRelease-1>", self.on_drag_end)
        self.pet_label.bind("<Button-3>", self.show_context_menu)
        self.pet_label.bind("<Double-Button-1>", self.on_double_click)
        
        # 拖拽相关变量
        self.drag_start_x = 0
        self.drag_start_y = 0
        
        # 键盘事件
        self.root.bind("<Escape>", lambda e: self.hide_sidebar())
    
    def setup_sidebar(self):
        """设置侧边栏"""
        # 侧边栏将在需要时创建
        pass
    
    def toggle_sidebar(self):
        """切换侧边栏显示/隐藏"""
        if self.sidebar_visible:
            self.hide_sidebar()
        else:
            self.show_sidebar()
    
    def show_sidebar(self):
        """显示侧边栏"""
        if self.sidebar is None:
            self.create_sidebar()
        
        # 获取主窗口位置
        main_x = self.root.winfo_x()
        main_y = self.root.winfo_y()
        
        # 侧边栏显示在主窗口右侧，缩小并增加距离
        sidebar_x = main_x + 300  # 进一步增加距离，从250改为300
        sidebar_y = main_y
        
        self.sidebar.geometry(f"250x400+{sidebar_x}+{sidebar_y}")  # 缩小尺寸，从300x500改为250x400
        self.sidebar.deiconify()
        self.sidebar_visible = True
    
    def hide_sidebar(self):
        """隐藏侧边栏"""
        if self.sidebar:
            self.sidebar.withdraw()
        self.sidebar_visible = False
    
    def create_sidebar(self):
        """创建侧边栏窗口"""
        self.sidebar = tk.Toplevel(self.root)
        self.sidebar.title("鼠鼠控制面板")
        self.sidebar.attributes('-topmost', True)
        self.sidebar.resizable(False, False)
        self.sidebar.protocol("WM_DELETE_WINDOW", self.hide_sidebar)
        
        # 创建侧边栏内容
        self.setup_sidebar_content()
    
    def setup_sidebar_content(self):
        """设置侧边栏内容"""
        # 主框架
        main_frame = ttk.Frame(self.sidebar, padding="10")
        main_frame.pack(fill='both', expand=True)
        
        # 控制面板
        control_frame = ttk.LabelFrame(main_frame, text="控制面板", padding="5")
        control_frame.pack(fill='x', pady=(0, 10))
        
        # 偷吃按钮
        self.steal_button = ttk.Button(control_frame, text="开始偷吃", command=self.start_stealing)
        self.steal_button.pack(side='left', padx=5)
        
        # 自动偷吃开关
        self.auto_var = tk.BooleanVar()
        self.auto_checkbox = ttk.Checkbutton(control_frame, text="自动偷吃", variable=self.auto_var, command=self.toggle_auto_steal)
        self.auto_checkbox.pack(side='left', padx=5)
        
        # 设置按钮
        self.settings_button = ttk.Button(control_frame, text="设置", command=self.open_settings)
        self.settings_button.pack(side='right', padx=5)
        
        # 状态信息
        status_frame = ttk.LabelFrame(main_frame, text="状态信息", padding="5")
        status_frame.pack(fill='x', pady=(0, 10))
        
        self.status_label = ttk.Label(status_frame, text="待机中...", font=('Arial', 10))
        self.status_label.pack()
        
        # 统计信息
        stats_frame = ttk.LabelFrame(main_frame, text="统计信息", padding="5")
        stats_frame.pack(fill='x', pady=(0, 10))
        
        self.stats_label = ttk.Label(stats_frame, text="总偷吃次数: 0\n总获得价值: 0", justify=tk.LEFT)
        self.stats_label.pack(anchor='w')
        
        # 最近获得物品（带图片显示）
        items_frame = ttk.LabelFrame(main_frame, text="最近获得物品", padding="5")
        items_frame.pack(fill='both', expand=True)
        
        # 创建滚动框架
        canvas = tk.Canvas(items_frame, height=200)
        scrollbar = ttk.Scrollbar(items_frame, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # 存储画布引用
        self.items_canvas = canvas
        
        # 初始化物品显示
        self.update_items_display()
    
    def start_drag(self, event):
        """开始拖拽窗口"""
        self.drag_start_x = event.x
        self.drag_start_y = event.y
    
    def on_drag(self, event):
        """拖拽窗口"""
        x = self.root.winfo_x() + event.x - self.drag_start_x
        y = self.root.winfo_y() + event.y - self.drag_start_y
        self.root.geometry(f"+{x}+{y}")
        
        # 拖拽时固定显示hudong动画
        if not self.is_playing:
            self.is_dragging = True
            self.current_action = "interaction"
        
        # 如果侧边栏可见，同时移动侧边栏
        if self.sidebar_visible and self.sidebar:
            sidebar_x = x + 300  # 与show_sidebar保持一致
            sidebar_y = y
            self.sidebar.geometry(f"250x400+{sidebar_x}+{sidebar_y}")  # 与show_sidebar保持一致
    
    def on_drag_end(self, event):
        """拖拽结束事件"""
        if self.is_dragging and not self.is_playing:
            self.is_dragging = False
            # 延迟回到待机状态，避免与单击事件冲突
            self.root.after(500, self.return_to_idle)
    
    def show_context_menu(self, event):
        """显示右键菜单"""
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()
    
    def on_double_click(self, event):
        """双击事件"""
        self.start_stealing()
    
    def on_single_click(self, event):
        """单击事件 - 开始拖拽并触发互动动画"""
        # 记录拖拽起始位置
        self.drag_start_x = event.x
        self.drag_start_y = event.y
        self.is_dragging = False
        
        # 触发互动动画（如果不在偷吃状态）
        if not self.is_playing and self.current_action == "idle":
            self.current_action = "interaction"
            # 2秒后回到待机状态
            self.root.after(2000, self.return_to_idle)
    
    def start_stealing(self):
        """开始偷吃"""
        if self.is_playing:
            return
        
        # 检查冷却时间
        if self.last_steal_time:
            cooldown = timedelta(seconds=self.config.steal_cooldown)
            if datetime.now() - self.last_steal_time < cooldown:
                remaining = cooldown - (datetime.now() - self.last_steal_time)
                messagebox.showinfo("冷却中", f"还需要等待 {remaining.seconds} 秒")
                return
        
        # 开始偷吃动画和逻辑
        self.is_playing = True
        self.current_action = "stealing"

        
        # 更新UI组件（如果存在）
        if hasattr(self, 'steal_button') and self.steal_button:
            self.steal_button.config(state="disabled")
        if hasattr(self, 'status_label') and self.status_label:
            self.status_label.config(text="偷吃中...")
        
        # 在后台线程执行偷吃逻辑
        threading.Thread(target=self.execute_steal, daemon=True).start()
    
    def execute_steal(self):
        """执行偷吃逻辑"""
        try:
            # 生成偷吃结果
            result = self.game_logic.generate_steal_result()
            
            # 模拟偷吃时间（增加10秒）
            time.sleep(random.uniform(12, 14))
            
            # 更新UI（在主线程中）
            self.root.after(0, self.on_steal_complete, result)
            
        except Exception as e:
            self.root.after(0, self.on_steal_error, str(e))
    
    def on_steal_complete(self, result):
        """偷吃完成回调"""
        self.is_playing = False
        self.current_action = "celebrating"
        self.last_steal_time = datetime.now()
        
        # 更新状态
        if result['success']:
            if hasattr(self, 'status_label') and self.status_label:
                self.status_label.config(text=f"获得了 {len(result['items'])} 个物品！")
            
            # 更新物品显示
            self.update_items_display(result['items'])
            
            # 生成并显示偷吃结果图片
            self.show_steal_result_image(result['items'])
        else:
            if hasattr(self, 'status_label') and self.status_label:
                self.status_label.config(text="偷吃失败了...")
        
        # 更新统计信息
        self.update_stats()
        
        # 重新启用按钮
        if hasattr(self, 'steal_button') and self.steal_button:
            self.steal_button.config(state="normal")
        
        # 3秒后回到待机状态
        self.root.after(3000, self.return_to_idle)
    
    def on_steal_error(self, error_msg):
        """偷吃错误回调"""
        self.is_playing = False
        self.current_action = "idle"
        if hasattr(self, 'status_label') and self.status_label:
            self.status_label.config(text="发生错误...")
        if hasattr(self, 'steal_button') and self.steal_button:
            self.steal_button.config(state="normal")
        messagebox.showerror("错误", f"偷吃过程中发生错误: {error_msg}")
    
    def return_to_idle(self):
        """返回待机状态"""
        self.current_action = "idle"
        if hasattr(self, 'status_label') and self.status_label:
            self.status_label.config(text="待机中...")
    
    def toggle_auto_steal(self):
        """切换自动偷吃"""
        self.auto_steal_enabled = self.auto_var.get()
        if hasattr(self, 'status_label') and self.status_label:
            if self.auto_steal_enabled:
                self.status_label.config(text="自动偷吃已启用")
            else:
                self.status_label.config(text="自动偷吃已禁用")
    
    def update_items_display(self, new_items=None):
         """更新物品显示"""
         if not hasattr(self, 'scrollable_frame'):
             return
         
         # 清空现有显示
         for widget in self.scrollable_frame.winfo_children():
             widget.destroy()
         
         # 获取最近的物品
         recent_items = self.game_logic.get_recent_items(20)
         
         # 如果有新物品，添加到列表开头
         if new_items:
             recent_items = new_items + recent_items
         
         # 显示物品
         for i, item in enumerate(recent_items[:20]):
             item_frame = ttk.Frame(self.scrollable_frame)
             item_frame.pack(fill='x', pady=2)
             
             # 尝试加载物品图片
             icon_widget = self.create_item_icon(item_frame, item)
             icon_widget.pack(side='left', padx=(0, 5))
             
             # 物品信息
             info_text = f"{item['name']}\n价值: {item['value']:,}"
             info_label = ttk.Label(item_frame, text=info_text, font=('Arial', 9))
             info_label.pack(side='left', anchor='w')
             
             # 点击查看详情
             item_frame.bind("<Button-1>", lambda e, item=item: self.show_item_detail(item))
             for child in item_frame.winfo_children():
                 child.bind("<Button-1>", lambda e, item=item: self.show_item_detail(item))
    
    def create_item_icon(self, parent, item):
        """创建物品图标"""
        try:
            # 尝试从items目录加载物品图片
            items_dir = os.path.join(os.path.dirname(__file__), '..', 'core', 'items')
            
            # 根据物品名称查找对应的图片文件
            item_name = item.get('base_name', item['name'])
            possible_extensions = ['.png', '.jpg', '.jpeg', '.gif', '.bmp']
            
            image_path = None
            for ext in possible_extensions:
                potential_path = os.path.join(items_dir, f"{item_name}{ext}")
                if os.path.exists(potential_path):
                    image_path = potential_path
                    break
            
            if image_path:
                # 加载并缩放图片
                with Image.open(image_path) as img:
                    img.thumbnail((32, 32), Image.LANCZOS)
                    photo = ImageTk.PhotoImage(img)
                    
                    # 创建带背景色的标签
                    quality_colors = {
                        'red': '#ffebee',
                        'purple': '#f3e5f5', 
                        'gold': '#fff8e1',
                        'blue': '#e3f2fd'
                    }
                    
                    bg_color = quality_colors.get(item.get('level', 'purple'), '#f5f5f5')
                    
                    icon_label = tk.Label(parent, image=photo, bg=bg_color, cursor='hand2')
                    icon_label.image = photo  # 保持引用
                    return icon_label
            
        except Exception as e:
            print(f"加载物品图片失败: {e}")
        
        # 备用方案：使用emoji图标
        level_icons = {
            'red': '🔴',
            'purple': '🟣', 
            'gold': '🟡',
            'blue': '🔵'
        }
        
        icon = level_icons.get(item.get('level', 'purple'), '📦')
        return ttk.Label(parent, text=icon, font=('Arial', 16), cursor='hand2')
    
    def show_item_detail(self, item):
        """显示物品详情"""
        detail_window = tk.Toplevel(self.sidebar)
        detail_window.title(f"物品详情 - {item['name']}")
        detail_window.geometry("300x400")
        detail_window.attributes('-topmost', True)
        detail_window.resizable(False, False)
        
        # 物品图片（大图）
        img_frame = ttk.Frame(detail_window)
        img_frame.pack(pady=10)
        
        large_icon = self.create_large_item_icon(img_frame, item)
        large_icon.pack()
        
        # 物品信息
        info_frame = ttk.LabelFrame(detail_window, text="物品信息", padding="10")
        info_frame.pack(fill='x', padx=10, pady=5)
        
        info_text = f"""名称: {item['name']}
品质: {item.get('level', 'unknown').upper()}
尺寸: {item.get('size', '1x1')}
价值: {item['value']:,}
获得时间: {item.get('time', '未知')}"""
        
        info_label = ttk.Label(info_frame, text=info_text, justify='left')
        info_label.pack(anchor='w')
        
        # 关闭按钮
        close_btn = ttk.Button(detail_window, text="关闭", command=detail_window.destroy)
        close_btn.pack(pady=10)
    
    def create_large_item_icon(self, parent, item):
         """创建大尺寸物品图标"""
         try:
             items_dir = os.path.join(os.path.dirname(__file__), '..', 'core', 'items')
             item_name = item.get('base_name', item['name'])
             possible_extensions = ['.png', '.jpg', '.jpeg', '.gif', '.bmp']
             
             image_path = None
             for ext in possible_extensions:
                 test_path = os.path.join(items_dir, f"{item_name}{ext}")
                 if os.path.exists(test_path):
                     image_path = test_path
                     break
             
             if image_path and os.path.exists(image_path):
                 with Image.open(image_path) as img:
                     img = img.convert('RGBA')
                     img.thumbnail((128, 128), Image.LANCZOS)
                     
                     # 添加品质背景
                     level = item.get('level', 'purple')
                     bg_colors = {
                         'purple': (128, 0, 128, 150),
                         'blue': (0, 100, 200, 150),
                         'gold': (255, 215, 0, 150),
                         'red': (200, 0, 0, 150)
                     }
                     
                     bg_color = bg_colors.get(level, (128, 128, 128, 150))
                     bg_img = Image.new('RGBA', (140, 140), bg_color)
                     
                     paste_x = (140 - img.width) // 2
                     paste_y = (140 - img.height) // 2
                     bg_img.paste(img, (paste_x, paste_y), img)
                     
                     # 转换为PhotoImage
                     photo = ImageTk.PhotoImage(bg_img)
                     label = tk.Label(parent, image=photo)
                     label.image = photo  # 保持引用
                     return label
         except Exception as e:
             print(f"Error loading large item image: {e}")
         
         # 备用显示
         level_icons = {
             'purple': '🟣',
             'blue': '🔵',
             'gold': '🟡', 
             'red': '🔴'
         }
         icon = level_icons.get(item.get('level', 'purple'), '📦')
         return ttk.Label(parent, text=icon, font=('Arial', 64))
    
    def show_steal_result_image(self, items):
         """显示偷吃结果图片"""
         if not items:
             return
         
         # 如果generate_safe_image不可用，使用简单结果显示
         if generate_safe_image is None:
             self.show_simple_result(items)
             return
         
         try:
             # 尝试生成偷吃结果图片
             image_path, placed_items = generate_safe_image(menggong_mode=False, grid_size=2)
             
             if image_path and os.path.exists(image_path):
                 # 创建结果显示窗口
                 result_window = tk.Toplevel(self.root)
                 result_window.title("偷吃结果")
                 result_window.attributes('-topmost', True)
                 result_window.resizable(False, False)
                 # 设置透明背景
                 result_window.attributes('-transparentcolor', 'white')
                 result_window.configure(bg='white')
                 # 移除窗口边框
                 result_window.overrideredirect(True)
                 
                 # 加载并显示图片
                 try:
                     with Image.open(image_path) as img:
                         # 缩小图片尺寸
                         img.thumbnail((250, 200), Image.LANCZOS)
                         photo = ImageTk.PhotoImage(img)
                         
                         img_label = tk.Label(result_window, image=photo, bg='white')
                         img_label.image = photo  # 保持引用
                         img_label.pack(padx=3, pady=3)
                         
                         # 添加物品信息（缩小字体）
                         total_value = sum(item['value'] for item in items)
                         info_text = f"获得 {len(items)} 个物品，总价值: {total_value:,}"
                         info_label = tk.Label(result_window, text=info_text, font=('Arial', 10, 'bold'), 
                                             bg='white', fg='black')
                         info_label.pack(pady=(0, 3))
                         
                         # 自动关闭
                         result_window.after(5000, result_window.destroy)
                         
                         # 显示在主窗口旁边，调整位置避免与侧边栏重叠
                         result_window.update_idletasks()
                         main_x = self.root.winfo_x()
                         main_y = self.root.winfo_y()
                         # 显示在主窗口右侧，但避免与侧边栏重叠
                         x = main_x + 160
                         y = main_y + 50
                         result_window.geometry(f"+{x}+{y}")
                         
                 except Exception as e:
                     print(f"Error displaying result image: {e}")
                     result_window.destroy()
             
         except Exception as e:
             print(f"Error generating steal result image: {e}")
             # 如果生成图片失败，显示简单的文字结果
             self.show_simple_result(items)
    
    def show_simple_result(self, items):
         """显示简单的文字结果（备用方案）"""
         result_window = tk.Toplevel(self.root)
         result_window.title("偷吃结果")
         result_window.attributes('-topmost', True)
         result_window.resizable(False, False)
         # 设置透明背景
         result_window.attributes('-transparentcolor', 'white')
         result_window.configure(bg='white')
         # 移除窗口边框
         result_window.overrideredirect(True)
         
         # 结果信息（透明背景）
         total_value = sum(item['value'] for item in items)
         result_text = f"恭喜！获得了 {len(items)} 个物品\n\n"
         
         for item in items[:5]:  # 最多显示5个物品
             result_text += f"• {item['name']} (价值: {item['value']:,})\n"
         
         if len(items) > 5:
             result_text += f"... 还有 {len(items) - 5} 个物品\n"
         
         result_text += f"\n总价值: {total_value:,}"
         
         info_label = tk.Label(result_window, text=result_text, justify='left',
                              bg='white', fg='black', font=('Arial', 10))
         info_label.pack(padx=10, pady=10)
         
         # 自动关闭
         result_window.after(3000, result_window.destroy)
         
         # 显示在主窗口旁边
         result_window.update_idletasks()
         main_x = self.root.winfo_x()
         main_y = self.root.winfo_y()
         # 显示在主窗口右侧
         x = main_x + 130
         y = main_y
         result_window.geometry(f"+{x}+{y}")
    
    def update_stats(self):
        """更新统计信息"""
        if not hasattr(self, 'stats_label'):
            return
        
        stats = self.game_logic.get_stats()
        stats_text = f"总偷吃次数: {stats['total_steals']}\n总获得价值: {stats['total_value']:,}"
        self.stats_label.config(text=stats_text)
    
    def open_settings(self):
        """打开设置窗口"""
        SettingsWindow(self.root, self.config)
    
    def start_animation_loop(self):
        """启动动画循环"""
        def animation_loop():
            while True:
                try:
                    # 尝试获取GIF动画帧
                    gif_frame = self.animation.get_gif_frame(self.current_action)
                    
                    # 添加调试信息
                    if self.current_action == "stealing":
                        print(f"偷吃动画状态: gif_frame存在={gif_frame is not None}")
                    
                    if gif_frame:
                        # 如果有GIF动画，显示GIF帧
                        self.root.after(0, lambda frame=gif_frame: self.pet_label.config(image=frame, text=""))
                    else:
                        # 如果没有GIF动画，使用文本表情符号
                        animation_frame = self.animation.get_current_frame(self.current_action)
                        self.root.after(0, lambda frame=animation_frame: self.pet_label.config(text=frame, image=""))
                    
                    time.sleep(0.1)  # 提高动画帧率以获得更流畅的GIF播放
                except Exception as e:
                    print(f"动画循环错误: {e}")
                    break
        
        threading.Thread(target=animation_loop, daemon=True).start()
    
    def start_game_loop(self):
        """启动游戏逻辑循环"""
        def game_loop():
            while True:
                try:
                    # 自动偷吃逻辑
                    if self.auto_steal_enabled and not self.is_playing:
                        if not self.last_steal_time or \
                           datetime.now() - self.last_steal_time >= timedelta(seconds=self.config.auto_steal_interval):
                            self.root.after(0, self.start_stealing)
                    
                    time.sleep(1)  # 检查间隔
                except:
                    break
        
        threading.Thread(target=game_loop, daemon=True).start()
    
    def on_closing(self):
        """窗口关闭事件"""
        # 保存配置
        self.config.save()
        
        # 保存游戏数据
        self.game_logic.save_data()
        
        # 关闭窗口
        self.root.destroy()
    
    def show_notification(self, title: str, message: str, duration: int = 3000, notification_type: str = 'info'):
        """显示通知"""
        try:
            from pet_utils import NotificationManager
            notification_manager = NotificationManager(self.root)
            notification_manager.show_notification(title, message, duration, notification_type)
        except Exception as e:
            if self.logger:
                self.logger.error(f"显示通知失败: {e}")
            # 备用方案：使用messagebox
            if notification_type == 'error':
                messagebox.showerror(title, message)
            elif notification_type == 'warning':
                messagebox.showwarning(title, message)
            else:
                messagebox.showinfo(title, message)
    
    def stop(self):
        """停止桌面宠物"""
        try:
            # 停止动画
            if hasattr(self, 'animation') and self.animation:
                self.animation.stop()
            
            # 停止自动偷吃
            if hasattr(self, 'auto_steal_active'):
                self.auto_steal_active = False
            
            # 关闭侧边栏
            if hasattr(self, 'sidebar') and self.sidebar:
                try:
                    self.sidebar.destroy()
                except:
                    pass
            
            # 保存配置和数据
            if hasattr(self, 'config') and self.config:
                self.config.save()
            
            if hasattr(self, 'game_logic') and self.game_logic:
                self.game_logic.save_data()
            
            if self.logger:
                self.logger.info("桌面宠物已停止")
                
        except Exception as e:
            print(f"停止桌面宠物时出错: {e}")
            if self.logger:
                self.logger.error(f"停止桌面宠物时出错: {e}")
    
    def run(self):
        """运行桌面宠物"""
        self.root.mainloop()

class SettingsWindow:
    """设置窗口"""
    def __init__(self, parent, config):
        self.config = config
        self.window = tk.Toplevel(parent)
        self.window.title("设置")
        self.window.geometry("400x300")
        self.window.transient(parent)
        self.window.grab_set()
        
        self.setup_ui()
    
    def setup_ui(self):
        """设置UI"""
        main_frame = ttk.Frame(self.window, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 冷却时间设置
        ttk.Label(main_frame, text="偷吃冷却时间(秒):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.cooldown_var = tk.StringVar(value=str(self.config.steal_cooldown))
        ttk.Entry(main_frame, textvariable=self.cooldown_var, width=10).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # 自动偷吃间隔
        ttk.Label(main_frame, text="自动偷吃间隔(秒):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.auto_interval_var = tk.StringVar(value=str(self.config.auto_steal_interval))
        ttk.Entry(main_frame, textvariable=self.auto_interval_var, width=10).grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # 窗口置顶
        self.topmost_var = tk.BooleanVar(value=self.config.always_on_top)
        ttk.Checkbutton(main_frame, text="窗口置顶", variable=self.topmost_var).grid(row=2, column=0, sticky=tk.W, pady=5)
        
        # 无边框模式
        self.borderless_var = tk.BooleanVar(value=self.config.borderless)
        ttk.Checkbutton(main_frame, text="无边框模式", variable=self.borderless_var).grid(row=3, column=0, sticky=tk.W, pady=5)
        
        # 按钮
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=20)
        
        ttk.Button(button_frame, text="保存", command=self.save_settings).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="取消", command=self.window.destroy).pack(side=tk.LEFT, padx=5)
    
    def save_settings(self):
        """保存设置"""
        try:
            self.config.steal_cooldown = int(self.cooldown_var.get())
            self.config.auto_steal_interval = int(self.auto_interval_var.get())
            self.config.always_on_top = self.topmost_var.get()
            self.config.borderless = self.borderless_var.get()
            
            self.config.save()
            messagebox.showinfo("成功", "设置已保存，重启程序后生效")
            self.window.destroy()
        except ValueError:
            messagebox.showerror("错误", "请输入有效的数字")

if __name__ == "__main__":
    # 创建并运行桌面宠物
    pet = DesktopPet()
    pet.run()