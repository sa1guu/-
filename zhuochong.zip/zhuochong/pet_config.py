#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
桌面宠物配置模块
管理宠物的各种设置和配置选项
"""

import os
import json
from typing import Dict, Any, Optional

class PetConfig:
    """桌面宠物配置类"""
    
    def __init__(self, config_file: Optional[str] = None):
        if config_file is None:
            config_file = os.path.join(os.path.dirname(__file__), 'pet_config.json')
        
        self.config_file = config_file
        self.load_default_config()
        self.load_config()
    
    def load_default_config(self):
        """加载默认配置"""
        self.default_config = {
            # 窗口设置
            'window': {
                'width': 400,
                'height': 500,
                'always_on_top': True,
                'borderless': False,
                'transparency': 0.95,
                'resizable': True,
                'start_position': 'center'  # center, top_left, top_right, bottom_left, bottom_right
            },
            
            # 游戏设置
            'game': {
                'steal_cooldown': 30,        # 偷吃冷却时间（秒）
                'auto_steal_interval': 300,  # 自动偷吃间隔（秒）
                'success_rate': 0.8,         # 基础成功率
                'min_items': 1,              # 最少获得物品数
                'max_items': 5,              # 最多获得物品数
                'enable_daily_bonus': True,  # 启用每日奖励
                'enable_combo_system': True, # 启用连击系统
                'enable_achievements': True  # 启用成就系统
            },
            
            # 动画设置
            'animation': {
                'enable_animations': True,
                'animation_speed': 1.0,      # 动画速度倍数
                'use_gif_animations': True,  # 使用GIF动画
                'enable_particles': True,    # 启用粒子效果
                'enable_floating_text': True, # 启用浮动文字
                'frame_rate': 30             # 动画帧率
            },
            
            # 音效设置
            'audio': {
                'enable_sound': True,
                'master_volume': 0.7,
                'sfx_volume': 0.8,
                'music_volume': 0.5,
                'mute_when_minimized': True
            },
            
            # 通知设置
            'notifications': {
                'enable_notifications': True,
                'show_steal_results': True,
                'show_achievements': True,
                'show_daily_reset': True,
                'notification_duration': 3000  # 毫秒
            },
            
            # 外观设置
            'appearance': {
                'theme': 'default',          # default, dark, light, custom
                'pet_size': 'medium',        # small, medium, large
                'show_status_bar': True,
                'show_stats_panel': True,
                'color_scheme': {
                    'primary': '#4CAF50',
                    'secondary': '#2196F3',
                    'accent': '#FF9800',
                    'background': '#FFFFFF',
                    'text': '#000000'
                }
            },
            
            # 行为设置
            'behavior': {
                'auto_steal_enabled': False,
                'smart_timing': True,        # 智能时机选择
                'adaptive_difficulty': True, # 自适应难度
                'learning_mode': False,      # 学习模式
                'idle_timeout': 300,         # 空闲超时（秒）
                'sleep_mode_enabled': True   # 睡眠模式
            },
            
            # 数据设置
            'data': {
                'auto_save_interval': 60,    # 自动保存间隔（秒）
                'backup_enabled': True,
                'max_history_items': 1000,
                'data_compression': False,
                'export_format': 'json'      # json, csv, xml
            },
            
            # 高级设置
            'advanced': {
                'debug_mode': False,
                'performance_mode': False,
                'memory_limit': 100,         # MB
                'cpu_limit': 10,             # 百分比
                'network_timeout': 30,       # 秒
                'cache_size': 50             # MB
            },
            
            # 快捷键设置
            'hotkeys': {
                'toggle_window': 'Ctrl+Shift+P',
                'start_steal': 'Ctrl+S',
                'toggle_auto': 'Ctrl+A',
                'show_stats': 'Ctrl+T',
                'settings': 'Ctrl+,'
            },
            
            # 插件设置
            'plugins': {
                'enabled_plugins': [],
                'plugin_directory': 'plugins',
                'auto_update_plugins': False
            }
        }
        
        # 将默认配置复制到当前配置
        self.config = self.default_config.copy()
    
    def load_config(self):
        """从文件加载配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    
                # 递归合并配置
                self.config = self._merge_configs(self.default_config, loaded_config)
            else:
                # 如果配置文件不存在，创建默认配置文件
                self.save_config()
        except Exception as e:
            print(f"加载配置文件失败: {e}")
            # 使用默认配置
            self.config = self.default_config.copy()
    
    def _merge_configs(self, default: Dict, loaded: Dict) -> Dict:
        """递归合并配置字典"""
        result = default.copy()
        
        for key, value in loaded.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        
        return result
    
    def save_config(self):
        """保存配置到文件"""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存配置文件失败: {e}")
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """获取配置值（支持点号分隔的路径）"""
        keys = key_path.split('.')
        value = self.config
        
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key_path: str, value: Any):
        """设置配置值（支持点号分隔的路径）"""
        keys = key_path.split('.')
        config = self.config
        
        # 导航到最后一级的父级
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        # 设置值
        config[keys[-1]] = value
    
    def reset_to_default(self, section: Optional[str] = None):
        """重置配置到默认值"""
        if section:
            if section in self.default_config:
                self.config[section] = self.default_config[section].copy()
        else:
            self.config = self.default_config.copy()
    
    def export_config(self, file_path: str):
        """导出配置到指定文件"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"导出配置失败: {e}")
            return False
    
    def import_config(self, file_path: str):
        """从指定文件导入配置"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                imported_config = json.load(f)
                self.config = self._merge_configs(self.default_config, imported_config)
            return True
        except Exception as e:
            print(f"导入配置失败: {e}")
            return False
    
    def validate_config(self) -> Dict[str, str]:
        """验证配置的有效性"""
        errors = {}
        
        # 验证窗口设置
        if self.get('window.width', 0) < 200:
            errors['window.width'] = '窗口宽度不能小于200像素'
        
        if self.get('window.height', 0) < 300:
            errors['window.height'] = '窗口高度不能小于300像素'
        
        if not 0.1 <= self.get('window.transparency', 1.0) <= 1.0:
            errors['window.transparency'] = '透明度必须在0.1到1.0之间'
        
        # 验证游戏设置
        if self.get('game.steal_cooldown', 0) < 1:
            errors['game.steal_cooldown'] = '偷吃冷却时间不能小于1秒'
        
        if not 0.0 <= self.get('game.success_rate', 0.8) <= 1.0:
            errors['game.success_rate'] = '成功率必须在0.0到1.0之间'
        
        if self.get('game.min_items', 1) < 1:
            errors['game.min_items'] = '最少物品数不能小于1'
        
        if self.get('game.max_items', 5) < self.get('game.min_items', 1):
            errors['game.max_items'] = '最多物品数不能小于最少物品数'
        
        # 验证动画设置
        if not 0.1 <= self.get('animation.animation_speed', 1.0) <= 5.0:
            errors['animation.animation_speed'] = '动画速度必须在0.1到5.0之间'
        
        if not 1 <= self.get('animation.frame_rate', 30) <= 120:
            errors['animation.frame_rate'] = '帧率必须在1到120之间'
        
        # 验证音效设置
        if not 0.0 <= self.get('audio.master_volume', 0.7) <= 1.0:
            errors['audio.master_volume'] = '主音量必须在0.0到1.0之间'
        
        return errors
    
    def get_theme_colors(self) -> Dict[str, str]:
        """获取主题颜色"""
        theme = self.get('appearance.theme', 'default')
        
        if theme == 'dark':
            return {
                'primary': '#BB86FC',
                'secondary': '#03DAC6',
                'accent': '#CF6679',
                'background': '#121212',
                'surface': '#1E1E1E',
                'text': '#FFFFFF',
                'text_secondary': '#B3B3B3'
            }
        elif theme == 'light':
            return {
                'primary': '#6200EE',
                'secondary': '#03DAC6',
                'accent': '#B00020',
                'background': '#FFFFFF',
                'surface': '#F5F5F5',
                'text': '#000000',
                'text_secondary': '#666666'
            }
        else:
            # 使用自定义或默认颜色
            return self.get('appearance.color_scheme', {
                'primary': '#4CAF50',
                'secondary': '#2196F3',
                'accent': '#FF9800',
                'background': '#FFFFFF',
                'text': '#000000'
            })
    
    def create_backup(self) -> str:
        """创建配置备份"""
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = f"{self.config_file}.backup_{timestamp}"
        
        try:
            self.export_config(backup_file)
            return backup_file
        except Exception as e:
            print(f"创建备份失败: {e}")
            return ""
    
    def restore_backup(self, backup_file: str) -> bool:
        """从备份恢复配置"""
        return self.import_config(backup_file)
    
    def get_performance_settings(self) -> Dict[str, Any]:
        """获取性能相关设置"""
        return {
            'performance_mode': self.get('advanced.performance_mode', False),
            'memory_limit': self.get('advanced.memory_limit', 100),
            'cpu_limit': self.get('advanced.cpu_limit', 10),
            'cache_size': self.get('advanced.cache_size', 50),
            'enable_animations': self.get('animation.enable_animations', True),
            'enable_particles': self.get('animation.enable_particles', True),
            'frame_rate': self.get('animation.frame_rate', 30)
        }
    
    def optimize_for_performance(self):
        """优化性能设置"""
        self.set('advanced.performance_mode', True)
        self.set('animation.enable_particles', False)
        self.set('animation.enable_floating_text', False)
        self.set('animation.frame_rate', 15)
        self.set('animation.animation_speed', 0.5)
    
    def optimize_for_quality(self):
        """优化质量设置"""
        self.set('advanced.performance_mode', False)
        self.set('animation.enable_particles', True)
        self.set('animation.enable_floating_text', True)
        self.set('animation.frame_rate', 60)
        self.set('animation.animation_speed', 1.0)
    
    # 便捷属性访问
    @property
    def window_width(self) -> int:
        return self.get('window.width', 400)
    
    @property
    def window_height(self) -> int:
        return self.get('window.height', 500)
    
    @property
    def always_on_top(self) -> bool:
        return self.get('window.always_on_top', True)
    
    @always_on_top.setter
    def always_on_top(self, value: bool):
        self.set('window.always_on_top', value)
    
    @property
    def borderless(self) -> bool:
        return self.get('window.borderless', False)
    
    @borderless.setter
    def borderless(self, value: bool):
        self.set('window.borderless', value)
    
    @property
    def steal_cooldown(self) -> int:
        return self.get('game.steal_cooldown', 30)
    
    @steal_cooldown.setter
    def steal_cooldown(self, value: int):
        self.set('game.steal_cooldown', max(1, value))
    
    @property
    def auto_steal_interval(self) -> int:
        return self.get('game.auto_steal_interval', 300)
    
    @auto_steal_interval.setter
    def auto_steal_interval(self, value: int):
        self.set('game.auto_steal_interval', max(10, value))
    
    @property
    def enable_sound(self) -> bool:
        return self.get('audio.enable_sound', True)
    
    @property
    def master_volume(self) -> float:
        return self.get('audio.master_volume', 0.7)
    
    def save(self):
        """保存配置（别名方法）"""
        self.save_config()