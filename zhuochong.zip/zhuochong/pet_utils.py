#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
桌面宠物工具模块
包含各种实用函数和辅助功能
"""

import os
import sys
import time
import random
import hashlib
import platform
import subprocess
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, filedialog
from PIL import Image, ImageTk, ImageDraw, ImageFont
import threading
import queue
import json
import datetime

class Logger:
    """简单的日志记录器"""
    
    def __init__(self, log_file: Optional[str] = None, level: str = 'INFO'):
        self.log_file = log_file
        self.level = level
        self.levels = {'DEBUG': 0, 'INFO': 1, 'WARNING': 2, 'ERROR': 3}
        
        if log_file:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
    
    def _log(self, level: str, message: str):
        if self.levels.get(level, 1) >= self.levels.get(self.level, 1):
            timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            log_message = f"[{timestamp}] [{level}] {message}"
            
            print(log_message)
            
            if self.log_file:
                try:
                    with open(self.log_file, 'a', encoding='utf-8') as f:
                        f.write(log_message + '\n')
                except Exception as e:
                    print(f"写入日志文件失败: {e}")
    
    def debug(self, message: str):
        self._log('DEBUG', message)
    
    def info(self, message: str):
        self._log('INFO', message)
    
    def warning(self, message: str):
        self._log('WARNING', message)
    
    def error(self, message: str):
        self._log('ERROR', message)

class ResourceManager:
    """资源管理器"""
    
    def __init__(self, base_dir: str):
        self.base_dir = Path(base_dir)
        self.cache = {}
        self.max_cache_size = 50  # 最大缓存项目数
    
    def get_image(self, path: str, size: Optional[Tuple[int, int]] = None) -> Optional[ImageTk.PhotoImage]:
        """获取图片资源"""
        cache_key = f"{path}_{size}"
        
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        try:
            full_path = self.base_dir / path
            if not full_path.exists():
                return None
            
            image = Image.open(full_path)
            
            if size:
                image = image.resize(size, Image.Resampling.LANCZOS)
            
            photo = ImageTk.PhotoImage(image)
            
            # 缓存管理
            if len(self.cache) >= self.max_cache_size:
                # 移除最旧的缓存项
                oldest_key = next(iter(self.cache))
                del self.cache[oldest_key]
            
            self.cache[cache_key] = photo
            return photo
        
        except Exception as e:
            print(f"加载图片失败 {path}: {e}")
            return None
    
    def get_gif_frames(self, path: str, size: Optional[Tuple[int, int]] = None) -> List[ImageTk.PhotoImage]:
        """获取GIF动画帧"""
        cache_key = f"gif_{path}_{size}"
        
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        try:
            full_path = self.base_dir / path
            if not full_path.exists():
                return []
            
            image = Image.open(full_path)
            frames = []
            
            try:
                while True:
                    frame = image.copy()
                    if size:
                        frame = frame.resize(size, Image.Resampling.LANCZOS)
                    frames.append(ImageTk.PhotoImage(frame))
                    image.seek(image.tell() + 1)
            except EOFError:
                pass
            
            self.cache[cache_key] = frames
            return frames
        
        except Exception as e:
            print(f"加载GIF失败 {path}: {e}")
            return []
    
    def clear_cache(self):
        """清空缓存"""
        self.cache.clear()

class SoundManager:
    """音效管理器"""
    
    def __init__(self, base_dir: str, enabled: bool = True):
        self.base_dir = Path(base_dir)
        self.enabled = enabled
        self.volume = 0.7
        
        # 尝试导入音频库
        self.audio_lib = None
        try:
            import pygame
            pygame.mixer.init()
            self.audio_lib = 'pygame'
        except ImportError:
            try:
                import playsound
                self.audio_lib = 'playsound'
            except ImportError:
                print("未找到音频库，音效功能将被禁用")
    
    def play_sound(self, sound_name: str):
        """播放音效"""
        if not self.enabled or not self.audio_lib:
            return
        
        try:
            sound_path = self.base_dir / f"{sound_name}.wav"
            if not sound_path.exists():
                sound_path = self.base_dir / f"{sound_name}.mp3"
            
            if not sound_path.exists():
                return
            
            if self.audio_lib == 'pygame':
                import pygame
                sound = pygame.mixer.Sound(str(sound_path))
                sound.set_volume(self.volume)
                sound.play()
            elif self.audio_lib == 'playsound':
                import playsound
                threading.Thread(target=playsound.playsound, args=(str(sound_path),), daemon=True).start()
        
        except Exception as e:
            print(f"播放音效失败 {sound_name}: {e}")
    
    def set_volume(self, volume: float):
        """设置音量"""
        self.volume = max(0.0, min(1.0, volume))
    
    def set_enabled(self, enabled: bool):
        """设置是否启用音效"""
        self.enabled = enabled

class NotificationManager:
    """通知管理器"""
    
    def __init__(self, parent_window: tk.Tk):
        self.parent = parent_window
        self.notifications = []
        self.max_notifications = 5
    
    def show_notification(self, title: str, message: str, duration: int = 3000, notification_type: str = 'info'):
        """显示通知"""
        try:
            # 创建通知窗口
            notification = tk.Toplevel(self.parent)
            notification.title(title)
            notification.geometry("300x100")
            notification.resizable(False, False)
            notification.attributes('-topmost', True)
            
            # 设置窗口位置（右下角）
            screen_width = notification.winfo_screenwidth()
            screen_height = notification.winfo_screenheight()
            x = screen_width - 320
            y = screen_height - 120 - len(self.notifications) * 110
            notification.geometry(f"300x100+{x}+{y}")
            
            # 设置颜色
            colors = {
                'info': {'bg': '#E3F2FD', 'fg': '#1976D2'},
                'success': {'bg': '#E8F5E8', 'fg': '#388E3C'},
                'warning': {'bg': '#FFF3E0', 'fg': '#F57C00'},
                'error': {'bg': '#FFEBEE', 'fg': '#D32F2F'}
            }
            
            color = colors.get(notification_type, colors['info'])
            notification.configure(bg=color['bg'])
            
            # 添加内容
            title_label = tk.Label(
                notification, 
                text=title, 
                font=('Arial', 10, 'bold'),
                bg=color['bg'], 
                fg=color['fg']
            )
            title_label.pack(pady=(10, 5))
            
            message_label = tk.Label(
                notification, 
                text=message, 
                font=('Arial', 9),
                bg=color['bg'], 
                fg=color['fg'],
                wraplength=280
            )
            message_label.pack(pady=(0, 10))
            
            # 添加到通知列表
            self.notifications.append(notification)
            
            # 限制通知数量
            if len(self.notifications) > self.max_notifications:
                old_notification = self.notifications.pop(0)
                old_notification.destroy()
            
            # 自动关闭
            def close_notification():
                if notification in self.notifications:
                    self.notifications.remove(notification)
                notification.destroy()
                self._reposition_notifications()
            
            notification.after(duration, close_notification)
            
            # 点击关闭
            notification.bind('<Button-1>', lambda e: close_notification())
            title_label.bind('<Button-1>', lambda e: close_notification())
            message_label.bind('<Button-1>', lambda e: close_notification())
        
        except Exception as e:
            print(f"显示通知失败: {e}")
    
    def _reposition_notifications(self):
        """重新定位通知"""
        screen_width = self.parent.winfo_screenwidth()
        screen_height = self.parent.winfo_screenheight()
        
        for i, notification in enumerate(self.notifications):
            x = screen_width - 320
            y = screen_height - 120 - i * 110
            notification.geometry(f"300x100+{x}+{y}")
    
    def clear_all(self):
        """清除所有通知"""
        for notification in self.notifications:
            notification.destroy()
        self.notifications.clear()

class AnimationHelper:
    """动画辅助类"""
    
    @staticmethod
    def ease_in_out(t: float) -> float:
        """缓入缓出动画曲线"""
        return t * t * (3.0 - 2.0 * t)
    
    @staticmethod
    def ease_in(t: float) -> float:
        """缓入动画曲线"""
        return t * t
    
    @staticmethod
    def ease_out(t: float) -> float:
        """缓出动画曲线"""
        return 1 - (1 - t) * (1 - t)
    
    @staticmethod
    def bounce(t: float) -> float:
        """弹跳动画曲线"""
        if t < 1/2.75:
            return 7.5625 * t * t
        elif t < 2/2.75:
            t -= 1.5/2.75
            return 7.5625 * t * t + 0.75
        elif t < 2.5/2.75:
            t -= 2.25/2.75
            return 7.5625 * t * t + 0.9375
        else:
            t -= 2.625/2.75
            return 7.5625 * t * t + 0.984375
    
    @staticmethod
    def elastic(t: float) -> float:
        """弹性动画曲线"""
        if t == 0 or t == 1:
            return t
        
        p = 0.3
        s = p / 4
        return -(2**(10*(t-1))) * math.sin((t-1-s)*(2*math.pi)/p)

class ColorUtils:
    """颜色工具类"""
    
    @staticmethod
    def hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
        """十六进制颜色转RGB"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    @staticmethod
    def rgb_to_hex(rgb: Tuple[int, int, int]) -> str:
        """RGB颜色转十六进制"""
        return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"
    
    @staticmethod
    def interpolate_color(color1: str, color2: str, t: float) -> str:
        """颜色插值"""
        rgb1 = ColorUtils.hex_to_rgb(color1)
        rgb2 = ColorUtils.hex_to_rgb(color2)
        
        r = int(rgb1[0] + (rgb2[0] - rgb1[0]) * t)
        g = int(rgb1[1] + (rgb2[1] - rgb1[1]) * t)
        b = int(rgb1[2] + (rgb2[2] - rgb1[2]) * t)
        
        return ColorUtils.rgb_to_hex((r, g, b))
    
    @staticmethod
    def get_random_color() -> str:
        """获取随机颜色"""
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        return ColorUtils.rgb_to_hex((r, g, b))
    
    @staticmethod
    def get_complementary_color(hex_color: str) -> str:
        """获取互补色"""
        rgb = ColorUtils.hex_to_rgb(hex_color)
        comp_rgb = (255 - rgb[0], 255 - rgb[1], 255 - rgb[2])
        return ColorUtils.rgb_to_hex(comp_rgb)

class FileUtils:
    """文件工具类"""
    
    @staticmethod
    def ensure_dir(path: str):
        """确保目录存在"""
        os.makedirs(path, exist_ok=True)
    
    @staticmethod
    def get_file_size(path: str) -> int:
        """获取文件大小（字节）"""
        try:
            return os.path.getsize(path)
        except OSError:
            return 0
    
    @staticmethod
    def get_file_hash(path: str) -> str:
        """获取文件MD5哈希"""
        try:
            with open(path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except Exception:
            return ""
    
    @staticmethod
    def backup_file(path: str, backup_dir: str = None) -> str:
        """备份文件"""
        if backup_dir is None:
            backup_dir = os.path.dirname(path)
        
        filename = os.path.basename(path)
        name, ext = os.path.splitext(filename)
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_filename = f"{name}_backup_{timestamp}{ext}"
        backup_path = os.path.join(backup_dir, backup_filename)
        
        try:
            import shutil
            shutil.copy2(path, backup_path)
            return backup_path
        except Exception as e:
            print(f"备份文件失败: {e}")
            return ""
    
    @staticmethod
    def clean_old_files(directory: str, days: int = 30, pattern: str = "*"):
        """清理旧文件"""
        try:
            import glob
            cutoff_time = time.time() - (days * 24 * 60 * 60)
            
            for file_path in glob.glob(os.path.join(directory, pattern)):
                if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                    os.remove(file_path)
                    print(f"删除旧文件: {file_path}")
        except Exception as e:
            print(f"清理旧文件失败: {e}")

class SystemUtils:
    """系统工具类"""
    
    @staticmethod
    def get_system_info() -> Dict[str, str]:
        """获取系统信息"""
        return {
            'platform': platform.platform(),
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'python_version': platform.python_version()
        }
    
    @staticmethod
    def get_memory_usage() -> Dict[str, float]:
        """获取内存使用情况"""
        try:
            import psutil
            memory = psutil.virtual_memory()
            return {
                'total': memory.total / (1024**3),  # GB
                'available': memory.available / (1024**3),
                'used': memory.used / (1024**3),
                'percentage': memory.percent
            }
        except ImportError:
            return {'error': 'psutil not available'}
    
    @staticmethod
    def get_cpu_usage() -> float:
        """获取CPU使用率"""
        try:
            import psutil
            return psutil.cpu_percent(interval=1)
        except ImportError:
            return 0.0
    
    @staticmethod
    def is_admin() -> bool:
        """检查是否以管理员权限运行"""
        try:
            if platform.system() == 'Windows':
                import ctypes
                return ctypes.windll.shell32.IsUserAnAdmin()
            else:
                return os.geteuid() == 0
        except Exception:
            return False
    
    @staticmethod
    def open_file_explorer(path: str):
        """打开文件资源管理器"""
        try:
            if platform.system() == 'Windows':
                os.startfile(path)
            elif platform.system() == 'Darwin':  # macOS
                subprocess.run(['open', path])
            else:  # Linux
                subprocess.run(['xdg-open', path])
        except Exception as e:
            print(f"打开文件资源管理器失败: {e}")

class MathUtils:
    """数学工具类"""
    
    @staticmethod
    def clamp(value: float, min_val: float, max_val: float) -> float:
        """限制数值范围"""
        return max(min_val, min(max_val, value))
    
    @staticmethod
    def lerp(a: float, b: float, t: float) -> float:
        """线性插值"""
        return a + (b - a) * t
    
    @staticmethod
    def distance(p1: Tuple[float, float], p2: Tuple[float, float]) -> float:
        """计算两点距离"""
        return ((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2)**0.5
    
    @staticmethod
    def normalize_angle(angle: float) -> float:
        """标准化角度到0-360度"""
        while angle < 0:
            angle += 360
        while angle >= 360:
            angle -= 360
        return angle
    
    @staticmethod
    def weighted_random_choice(choices: List[Tuple[Any, float]]) -> Any:
        """加权随机选择"""
        total_weight = sum(weight for _, weight in choices)
        r = random.uniform(0, total_weight)
        
        current_weight = 0
        for choice, weight in choices:
            current_weight += weight
            if r <= current_weight:
                return choice
        
        return choices[-1][0] if choices else None

class PerformanceMonitor:
    """性能监控器"""
    
    def __init__(self):
        self.start_time = time.time()
        self.frame_times = []
        self.max_frame_times = 60
    
    def start_frame(self):
        """开始帧计时"""
        self.frame_start = time.time()
    
    def end_frame(self):
        """结束帧计时"""
        frame_time = time.time() - self.frame_start
        self.frame_times.append(frame_time)
        
        if len(self.frame_times) > self.max_frame_times:
            self.frame_times.pop(0)
    
    def get_fps(self) -> float:
        """获取FPS"""
        if not self.frame_times:
            return 0.0
        
        avg_frame_time = sum(self.frame_times) / len(self.frame_times)
        return 1.0 / avg_frame_time if avg_frame_time > 0 else 0.0
    
    def get_frame_time_ms(self) -> float:
        """获取平均帧时间（毫秒）"""
        if not self.frame_times:
            return 0.0
        
        return (sum(self.frame_times) / len(self.frame_times)) * 1000
    
    def get_uptime(self) -> float:
        """获取运行时间（秒）"""
        return time.time() - self.start_time

class TaskScheduler:
    """任务调度器"""
    
    def __init__(self):
        self.tasks = []
        self.running = False
        self.thread = None
    
    def add_task(self, func, interval: float, *args, **kwargs):
        """添加定时任务"""
        task = {
            'func': func,
            'interval': interval,
            'args': args,
            'kwargs': kwargs,
            'last_run': 0,
            'enabled': True
        }
        self.tasks.append(task)
    
    def remove_task(self, func):
        """移除任务"""
        self.tasks = [task for task in self.tasks if task['func'] != func]
    
    def start(self):
        """启动调度器"""
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()
    
    def stop(self):
        """停止调度器"""
        self.running = False
        if self.thread:
            self.thread.join()
    
    def _run(self):
        """运行调度器"""
        while self.running:
            current_time = time.time()
            
            for task in self.tasks:
                if (task['enabled'] and 
                    current_time - task['last_run'] >= task['interval']):
                    
                    try:
                        task['func'](*task['args'], **task['kwargs'])
                        task['last_run'] = current_time
                    except Exception as e:
                        print(f"任务执行失败: {e}")
            
            time.sleep(0.1)  # 100ms检查间隔

def create_gradient_image(width: int, height: int, color1: str, color2: str, direction: str = 'vertical') -> Image.Image:
    """创建渐变图像"""
    image = Image.new('RGB', (width, height))
    draw = ImageDraw.Draw(image)
    
    rgb1 = ColorUtils.hex_to_rgb(color1)
    rgb2 = ColorUtils.hex_to_rgb(color2)
    
    if direction == 'vertical':
        for y in range(height):
            t = y / height
            r = int(rgb1[0] + (rgb2[0] - rgb1[0]) * t)
            g = int(rgb1[1] + (rgb2[1] - rgb1[1]) * t)
            b = int(rgb1[2] + (rgb2[2] - rgb1[2]) * t)
            draw.line([(0, y), (width, y)], fill=(r, g, b))
    else:  # horizontal
        for x in range(width):
            t = x / width
            r = int(rgb1[0] + (rgb2[0] - rgb1[0]) * t)
            g = int(rgb1[1] + (rgb2[1] - rgb1[1]) * t)
            b = int(rgb1[2] + (rgb2[2] - rgb1[2]) * t)
            draw.line([(x, 0), (x, height)], fill=(r, g, b))
    
    return image

def format_time_duration(seconds: float) -> str:
    """格式化时间持续时间"""
    if seconds < 60:
        return f"{seconds:.1f}秒"
    elif seconds < 3600:
        minutes = seconds // 60
        secs = seconds % 60
        return f"{int(minutes)}分{int(secs)}秒"
    else:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{int(hours)}小时{int(minutes)}分钟"

def format_number(number: Union[int, float], precision: int = 2) -> str:
    """格式化数字显示"""
    if isinstance(number, float):
        if number >= 1000000:
            return f"{number/1000000:.{precision}f}M"
        elif number >= 1000:
            return f"{number/1000:.{precision}f}K"
        else:
            return f"{number:.{precision}f}"
    else:
        if number >= 1000000:
            return f"{number//1000000}M"
        elif number >= 1000:
            return f"{number//1000}K"
        else:
            return str(number)

def get_random_encouragement() -> str:
    """获取随机鼓励语句"""
    encouragements = [
        "继续加油！🎉",
        "你做得很棒！✨",
        "再接再厉！💪",
        "运气不错呢！🍀",
        "太厉害了！🌟",
        "保持这个节奏！🚀",
        "你是最棒的！👑",
        "好运连连！🎊",
        "技术精湛！🎯",
        "势不可挡！⚡"
    ]
    return random.choice(encouragements)

def get_random_failure_message() -> str:
    """获取随机失败消息"""
    messages = [
        "下次一定！😅",
        "再试一次吧！🤔",
        "运气欠佳呢！😢",
        "不要放弃！💪",
        "失败是成功之母！📚",
        "再来一次！🔄",
        "坚持就是胜利！⭐",
        "相信自己！💫",
        "机会总会来的！🌈",
        "加油加油！🔥"
    ]
    return random.choice(messages)

def validate_config_value(value: Any, value_type: type, min_val: Any = None, max_val: Any = None) -> bool:
    """验证配置值"""
    try:
        # 类型检查
        if not isinstance(value, value_type):
            return False
        
        # 范围检查
        if min_val is not None and value < min_val:
            return False
        
        if max_val is not None and value > max_val:
            return False
        
        return True
    except Exception:
        return False

def safe_divide(a: float, b: float, default: float = 0.0) -> float:
    """安全除法"""
    try:
        return a / b if b != 0 else default
    except (TypeError, ZeroDivisionError):
        return default

def create_rounded_rectangle(width: int, height: int, radius: int, color: str) -> Image.Image:
    """创建圆角矩形图像"""
    image = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    
    # 绘制圆角矩形
    draw.rounded_rectangle(
        [(0, 0), (width-1, height-1)], 
        radius=radius, 
        fill=color
    )
    
    return image