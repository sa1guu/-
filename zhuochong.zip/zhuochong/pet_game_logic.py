#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
桌面宠物游戏逻辑模块
处理偷吃功能的核心逻辑
"""

import os
import sys
import random
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional

# 添加核心模块路径
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'core'))

try:
    from touchi import load_items, get_item_value, create_safe_layout, generate_safe_image
except ImportError:
    # 如果导入失败，提供备用实现
    def load_items():
        return []
    def get_item_value(item_name):
        return 1000
    def create_safe_layout(items, menggong_mode=False, grid_size=2):
        return [], 0, 0, 2, 2
    def generate_safe_image(menggong_mode=False, grid_size=2):
        return None, []

class PetGameLogic:
    """桌面宠物游戏逻辑类"""
    
    def __init__(self):
        self.data_file = os.path.join(os.path.dirname(__file__), 'pet_data.json')
        self.load_data()
        
        # 游戏配置
        self.success_rate = 0.8  # 偷吃成功率
        self.min_items = 1       # 最少获得物品数
        self.max_items = 5       # 最多获得物品数
        
        # 稀有度权重
        self.rarity_weights = {
            'blue': 50,    # 蓝色物品权重
            'purple': 30,  # 紫色物品权重
            'gold': 15,    # 金色物品权重
            'red': 5       # 红色物品权重
        }
    
    def load_data(self):
        """加载游戏数据"""
        default_data = {
            'total_steals': 0,
            'total_value': 0,
            'successful_steals': 0,
            'failed_steals': 0,
            'items_obtained': [],
            'last_steal_time': None,
            'daily_steals': 0,
            'daily_reset_date': datetime.now().strftime('%Y-%m-%d')
        }
        
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    self.data = json.load(f)
                    
                # 检查是否需要重置每日数据
                today = datetime.now().strftime('%Y-%m-%d')
                if self.data.get('daily_reset_date') != today:
                    self.data['daily_steals'] = 0
                    self.data['daily_reset_date'] = today
            else:
                self.data = default_data
        except Exception as e:
            print(f"加载游戏数据失败: {e}")
            self.data = default_data
    
    def save_data(self):
        """保存游戏数据"""
        try:
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存游戏数据失败: {e}")
    
    def generate_steal_result(self) -> Dict:
        """生成偷吃结果"""
        # 更新统计
        self.data['total_steals'] += 1
        self.data['daily_steals'] += 1
        self.data['last_steal_time'] = datetime.now().isoformat()
        
        # 判断是否成功
        success = random.random() < self.success_rate
        
        if success:
            self.data['successful_steals'] += 1
            items = self._generate_items()
            total_value = sum(item['value'] for item in items)
            self.data['total_value'] += total_value
            
            # 记录获得的物品
            for item in items:
                self.data['items_obtained'].append({
                    'name': item['name'],
                    'base_name': item.get('base_name', 'unknown'),
                    'value': item['value'],
                    'rarity': item['rarity'],
                    'level': item.get('level', item['rarity']),
                    'size': item.get('size', '1x1'),
                    'path': item.get('path', ''),
                    'obtained_time': datetime.now().isoformat(),
                    'time': item.get('time', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                })
            
            # 限制历史记录长度
            if len(self.data['items_obtained']) > 100:
                self.data['items_obtained'] = self.data['items_obtained'][-100:]
            
            result = {
                'success': True,
                'items': items,
                'total_value': total_value,
                'message': f"偷吃成功！获得了 {len(items)} 个物品，总价值 {total_value:,}"
            }
        else:
            self.data['failed_steals'] += 1
            result = {
                'success': False,
                'items': [],
                'total_value': 0,
                'message': "偷吃失败了，什么都没有获得..."
            }
        
        # 保存数据
        self.save_data()
        
        return result
    
    def _generate_items(self) -> List[Dict]:
        """生成获得的物品"""
        items = []
        
        # 加载可用物品
        available_items = load_items()
        if not available_items:
            # 如果没有物品数据，生成模拟物品
            available_items = self._generate_mock_items()
        
        # 确定获得物品数量
        num_items = random.randint(self.min_items, self.max_items)
        
        # 根据每日偷吃次数调整奖励
        daily_bonus = min(self.data['daily_steals'] * 0.1, 1.0)  # 最多100%奖励
        
        for _ in range(num_items):
            # 选择稀有度
            rarity = self._choose_rarity(daily_bonus)
            
            # 从对应稀有度中选择物品
            rarity_items = [item for item in available_items if item.get('level', 'blue') == rarity]
            if not rarity_items:
                rarity_items = available_items
            
            if rarity_items:
                chosen_item = random.choice(rarity_items)
                
                # 应用价值波动
                base_value = chosen_item.get('value', get_item_value(chosen_item.get('base_name', 'unknown')))
                value_multiplier = random.uniform(0.8, 1.2)  # ±20%价值波动
                final_value = int(base_value * value_multiplier * (1 + daily_bonus))
                
                items.append({
                    'name': chosen_item.get('name', chosen_item.get('base_name', 'Unknown Item')),
                    'base_name': chosen_item.get('base_name', 'unknown'),
                    'value': final_value,
                    'rarity': rarity,
                    'level': rarity,  # 添加level字段以保持兼容性
                    'size': chosen_item.get('size', '1x1'),
                    'path': chosen_item.get('path', ''),
                    'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
        
        return items
    
    def _choose_rarity(self, bonus_multiplier: float = 0) -> str:
        """根据权重选择稀有度"""
        # 应用奖励倍数到高稀有度物品
        weights = self.rarity_weights.copy()
        weights['gold'] = int(weights['gold'] * (1 + bonus_multiplier))
        weights['red'] = int(weights['red'] * (1 + bonus_multiplier * 2))
        
        # 创建加权列表
        weighted_list = []
        for rarity, weight in weights.items():
            weighted_list.extend([rarity] * weight)
        
        return random.choice(weighted_list)
    
    def _generate_mock_items(self) -> List[Dict]:
        """生成模拟物品数据（当无法加载真实物品时）"""
        mock_items = [
            {'name': '神秘宝石', 'level': 'red', 'value': 50000, 'size': '1x1', 'base_name': 'red_1x1_xin'},
            {'name': '黄金硬币', 'level': 'gold', 'value': 10000, 'size': '1x1', 'base_name': 'gold_1x1_jinbi'},
            {'name': '紫水晶', 'level': 'purple', 'value': 5000, 'size': '1x1', 'base_name': 'purple_1x1_wandao'},
            {'name': '蓝宝石', 'level': 'blue', 'value': 2000, 'size': '1x1', 'base_name': 'blue_1x1_yinbi'},
            {'name': '能量核心', 'level': 'red', 'value': 80000, 'size': '2x2', 'base_name': 'red_2x2_jingui'},
            {'name': '魔法书', 'level': 'gold', 'value': 15000, 'size': '1x2', 'base_name': 'gold_1x2_longshelan'},
            {'name': '治疗药水', 'level': 'purple', 'value': 3000, 'size': '1x1', 'base_name': 'purple_1x1_shoudian'},
            {'name': '铁剑', 'level': 'blue', 'value': 1500, 'size': '1x3', 'base_name': 'blue_1x3_luyin'},
            {'name': '龙鳞', 'level': 'red', 'value': 100000, 'size': '1x1', 'base_name': 'red_1x1_1'},
            {'name': '法师帽', 'level': 'gold', 'value': 12000, 'size': '2x1', 'base_name': 'gold_2x1_qiangxieliangjian'}
        ]
        
        return mock_items
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        success_rate = 0
        if self.data['total_steals'] > 0:
            success_rate = (self.data['successful_steals'] / self.data['total_steals']) * 100
        
        return {
            'total_steals': self.data['total_steals'],
            'successful_steals': self.data['successful_steals'],
            'failed_steals': self.data['failed_steals'],
            'success_rate': success_rate,
            'total_value': self.data['total_value'],
            'daily_steals': self.data['daily_steals'],
            'average_value_per_steal': self.data['total_value'] / max(self.data['successful_steals'], 1),
            'last_steal_time': self.data['last_steal_time']
        }
    
    def get_recent_items(self, limit: int = 10) -> List[Dict]:
        """获取最近获得的物品"""
        return self.data['items_obtained'][-limit:] if self.data['items_obtained'] else []
    
    def reset_stats(self):
        """重置统计数据"""
        self.data = {
            'total_steals': 0,
            'total_value': 0,
            'successful_steals': 0,
            'failed_steals': 0,
            'items_obtained': [],
            'last_steal_time': None,
            'daily_steals': 0,
            'daily_reset_date': datetime.now().strftime('%Y-%m-%d')
        }
        self.save_data()
    
    def can_steal(self, cooldown_seconds: int) -> Tuple[bool, Optional[int]]:
        """检查是否可以偷吃"""
        if not self.data['last_steal_time']:
            return True, None
        
        last_time = datetime.fromisoformat(self.data['last_steal_time'])
        cooldown = timedelta(seconds=cooldown_seconds)
        time_passed = datetime.now() - last_time
        
        if time_passed >= cooldown:
            return True, None
        else:
            remaining = cooldown - time_passed
            return False, int(remaining.total_seconds())
    
    def get_daily_progress(self) -> Dict:
        """获取每日进度"""
        # 每日目标
        daily_targets = {
            'steals': 10,
            'value': 50000
        }
        
        # 计算今日获得的价值
        today = datetime.now().strftime('%Y-%m-%d')
        daily_value = 0
        
        for item in self.data['items_obtained']:
            if 'obtained_time' in item:
                item_date = datetime.fromisoformat(item['obtained_time']).strftime('%Y-%m-%d')
                if item_date == today:
                    daily_value += item['value']
        
        return {
            'daily_steals': self.data['daily_steals'],
            'daily_value': daily_value,
            'steal_progress': min(self.data['daily_steals'] / daily_targets['steals'], 1.0),
            'value_progress': min(daily_value / daily_targets['value'], 1.0),
            'targets': daily_targets
        }
    
    def generate_safe_image_result(self, menggong_mode: bool = False) -> Optional[str]:
        """生成保险箱图片"""
        try:
            image_path, placed_items = generate_safe_image(menggong_mode=menggong_mode)
            return image_path
        except Exception as e:
            print(f"生成保险箱图片失败: {e}")
            return None
    
    def get_achievement_progress(self) -> Dict:
        """获取成就进度"""
        achievements = {
            'first_steal': {
                'name': '初次偷吃',
                'description': '完成第一次偷吃',
                'target': 1,
                'current': min(self.data['total_steals'], 1),
                'completed': self.data['total_steals'] >= 1
            },
            'steal_master': {
                'name': '偷吃大师',
                'description': '完成100次偷吃',
                'target': 100,
                'current': min(self.data['total_steals'], 100),
                'completed': self.data['total_steals'] >= 100
            },
            'value_collector': {
                'name': '财富收集者',
                'description': '累计获得100万价值',
                'target': 1000000,
                'current': min(self.data['total_value'], 1000000),
                'completed': self.data['total_value'] >= 1000000
            },
            'lucky_streak': {
                'name': '幸运连击',
                'description': '连续成功偷吃10次',
                'target': 10,
                'current': self._get_current_streak(),
                'completed': self._get_current_streak() >= 10
            }
        }
        
        return achievements
    
    def _get_current_streak(self) -> int:
        """获取当前连击数"""
        # 这里可以实现更复杂的连击逻辑
        # 简化版本：基于成功率估算
        if self.data['total_steals'] == 0:
            return 0
        
        success_rate = self.data['successful_steals'] / self.data['total_steals']
        estimated_streak = int(success_rate * 10)
        return min(estimated_streak, 10)