# 🐭 鼠鼠偷吃桌面宠物

一个可爱的桌面宠物应用，移植自原有的"鼠鼠偷吃"功能，让你的桌面更加生动有趣！

## ✨ 功能特色

### 🎮 核心游戏功能
- **偷吃系统**: 点击偷吃按钮，随机获得各种物品
- **自动偷吃**: 设置自动偷吃间隔，解放双手
- **连击系统**: 连续成功偷吃可获得额外奖励
- **物品收集**: 收集各种稀有物品，建立你的宝库
- **等级系统**: 通过偷吃获得经验值，提升等级

### 🏆 成就系统
- **多样化成就**: 15种不同类型的成就等你解锁
- **进度追踪**: 实时显示成就完成进度
- **特殊奖励**: 解锁成就获得特殊称号和奖励

### 📊 统计功能
- **详细数据**: 偷吃次数、成功率、总价值等统计
- **历史记录**: 查看偷吃历史和物品获得记录
- **每日统计**: 每日偷吃数据分析
- **物品统计**: 各种物品的获得次数和价值统计

### 🎨 视觉效果
- **动画系统**: 丰富的动画效果和过渡
- **GIF支持**: 支持GIF动画作为宠物形象
- **粒子效果**: 偷吃成功时的粒子特效
- **浮动文字**: 动态显示获得的物品和价值
- **主题系统**: 多种主题可选（默认、暗色、亮色）

### 🔧 个性化设置
- **窗口设置**: 大小、位置、透明度、置顶等
- **游戏设置**: 冷却时间、成功率、物品数量等
- **外观设置**: 主题、颜色、动画效果等
- **行为设置**: 自动偷吃、智能时机等
- **快捷键**: 自定义快捷键操作

## 🚀 快速开始

### 系统要求
- **操作系统**: Windows 7/10/11, macOS 10.12+, Linux
- **Python版本**: Python 3.7 或更高版本
- **内存**: 至少 100MB 可用内存
- **磁盘空间**: 至少 100MB 可用空间

### 必需依赖
```bash
pip install Pillow
```

### 可选依赖（增强功能）
```bash
# 音效支持
pip install pygame
# 或者
pip install playsound

# 系统监控
pip install psutil
```

### 安装步骤

1. **下载源码**
   ```bash
   git clone <repository-url>
   cd zhuochong
   ```

2. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

3. **准备资源文件**
   - 将GIF动画文件放入 `biqoqinggif/` 目录
   - 将音效文件放入 `sounds/` 目录
   - 将图标文件 `icon.ico` 放入根目录

4. **运行应用**
   ```bash
   python main.py
   ```

## 📁 目录结构

```
zhuochong/
├── main.py                 # 主程序入口
├── desktop_pet.py          # 桌面宠物主类
├── pet_game_logic.py       # 游戏逻辑
├── pet_animation.py        # 动画系统
├── pet_config.py           # 配置管理
├── pet_data.py             # 数据管理
├── pet_utils.py            # 工具函数
├── README.md               # 说明文档
├── requirements.txt        # 依赖列表
├── data/                   # 数据目录
│   ├── user_data.json      # 用户数据
│   ├── achievements.json   # 成就数据
│   └── history.db          # 历史数据库
├── biqoqinggif/           # GIF动画目录
├── sounds/                # 音效目录
├── logs/                  # 日志目录
├── cache/                 # 缓存目录
├── backups/               # 备份目录
└── themes/                # 主题目录
```

## 🎮 使用指南

### 基本操作

1. **开始偷吃**
   - 点击"开始偷吃"按钮
   - 或使用快捷键 `Ctrl+S`
   - 等待冷却时间结束后可再次偷吃

2. **自动偷吃**
   - 点击"自动偷吃"开关
   - 或使用快捷键 `Ctrl+A`
   - 设置自动偷吃间隔时间

3. **查看统计**
   - 点击"统计"按钮
   - 或使用快捷键 `Ctrl+T`
   - 查看详细的偷吃数据和成就进度

4. **设置选项**
   - 点击"设置"按钮
   - 或使用快捷键 `Ctrl+,`
   - 自定义各种游戏和外观设置

### 快捷键列表

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+S` | 开始偷吃 |
| `Ctrl+A` | 切换自动偷吃 |
| `Ctrl+T` | 显示统计 |
| `Ctrl+,` | 打开设置 |
| `Ctrl+Shift+P` | 切换窗口显示/隐藏 |

### 成就系统

#### 基础成就
- **初次偷吃**: 完成第一次偷吃
- **小偷新手**: 成功偷吃10次
- **偷吃大师**: 成功偷吃100次
- **传奇大盗**: 成功偷吃1000次

#### 连击成就
- **连击新手**: 达成5连击
- **连击高手**: 达成20连击
- **连击大师**: 达成50连击

#### 财富成就
- **财富积累者**: 累计获得价值1000
- **富翁**: 累计获得价值10000

#### 特殊成就
- **勤奋偷吃者**: 单日偷吃10次
- **幸运日**: 单日成功率100%（至少5次）
- **收藏家**: 收集50种不同物品
- **速度恶魔**: 1分钟内完成3次偷吃
- **夜猫子**: 在凌晨2-6点偷吃
- **早起鸟**: 在早晨6-8点偷吃

## ⚙️ 配置说明

### 窗口设置
```json
{
  "window": {
    "width": 400,              // 窗口宽度
    "height": 500,             // 窗口高度
    "always_on_top": true,     // 窗口置顶
    "borderless": false,       // 无边框模式
    "transparency": 0.95,       // 透明度 (0.1-1.0)
    "resizable": true,          // 可调整大小
    "start_position": "center"  // 启动位置
  }
}
```

### 游戏设置
```json
{
  "game": {
    "steal_cooldown": 30,        // 偷吃冷却时间（秒）
    "auto_steal_interval": 300,  // 自动偷吃间隔（秒）
    "success_rate": 0.8,         // 基础成功率 (0.0-1.0)
    "min_items": 1,              // 最少获得物品数
    "max_items": 5,              // 最多获得物品数
    "enable_daily_bonus": true,  // 启用每日奖励
    "enable_combo_system": true, // 启用连击系统
    "enable_achievements": true  // 启用成就系统
  }
}
```

### 动画设置
```json
{
  "animation": {
    "enable_animations": true,   // 启用动画
    "animation_speed": 1.0,      // 动画速度倍数
    "use_gif_animations": true,  // 使用GIF动画
    "enable_particles": true,    // 启用粒子效果
    "enable_floating_text": true, // 启用浮动文字
    "frame_rate": 30             // 动画帧率
  }
}
```

## 🎨 自定义主题

### 创建自定义主题

1. 在 `themes/` 目录下创建新的主题文件 `my_theme.json`
2. 定义主题配置：

```json
{
  "name": "我的主题",
  "colors": {
    "primary": "#FF6B6B",
    "secondary": "#4ECDC4",
    "accent": "#45B7D1",
    "background": "#F8F9FA",
    "text": "#2C3E50"
  },
  "fonts": {
    "default": "Arial",
    "title": "Arial Bold",
    "mono": "Consolas"
  }
}
```

3. 在设置中选择新主题

## 🔧 故障排除

### 常见问题

**Q: 应用无法启动**
A: 检查Python版本是否为3.7+，确保安装了Pillow库

**Q: 没有声音**
A: 安装pygame或playsound库，检查音效文件是否存在

**Q: 动画卡顿**
A: 降低动画帧率，关闭粒子效果，启用性能模式

**Q: 数据丢失**
A: 检查data目录权限，启用自动备份功能

**Q: 窗口显示异常**
A: 重置窗口设置到默认值，检查屏幕分辨率

### 日志文件

应用运行日志保存在 `logs/pet.log`，包含详细的错误信息和运行状态。

### 数据备份

- 用户数据: `data/user_data.json`
- 成就数据: `data/achievements.json`
- 历史记录: `data/history.db`
- 配置文件: `pet_config.json`

建议定期备份这些文件。

## 🤝 贡献指南

欢迎提交Issue和Pull Request！

### 开发环境设置

1. Fork项目
2. 创建功能分支
3. 安装开发依赖
4. 运行测试
5. 提交更改

### 代码规范

- 使用Python PEP 8代码风格
- 添加适当的注释和文档字符串
- 编写单元测试
- 更新相关文档

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

- 感谢原始"鼠鼠偷吃"功能的开发者
- 感谢所有贡献者和测试用户
- 使用的开源库：Pillow, tkinter, sqlite3

## 📞 联系方式

如有问题或建议，请通过以下方式联系：

- 提交Issue: [GitHub Issues]()
- 邮箱: [your-email@example.com]()

---

**享受你的桌面宠物吧！** 🐭✨