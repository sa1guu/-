#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
桌面宠物动画模块
处理宠物的各种动画状态和表情
"""

import os
import random
import time
from typing import Dict, List, Optional
from PIL import Image, ImageTk
import tkinter as tk

class PetAnimation:
    """桌面宠物动画类"""
    
    def __init__(self):
        self.gif_dir = os.path.join(os.path.dirname(__file__), 'biqoqinggif')
        self.current_frame = 0
        self.animation_speed = 0.5  # 动画速度（秒）
        self.last_frame_time = time.time()
        
        # GIF循环控制
        self.gif_loop_count = 0  # 当前循环次数
        self.max_loops = 2  # 每个GIF循环2次后切换
        self.current_gif_index = 0  # 当前GIF索引
        
        # 动画状态
        self.animations = {
            'idle': {
                'frames': ['🐭', '🐹', '🐭', '🐹'],
                'speed': 1.0,
                'loop': True
            },
            'stealing': {
                'frames': ['🐭💨', '🐹💨', '🐭💰', '🐹💰', '🐭🔍', '🐹🔍'],
                'speed': 0.3,
                'loop': True
            },
            'celebrating': {
                'frames': ['🐭🎉', '🐹🎉', '🐭✨', '🐹✨', '🐭🏆', '🐹🏆'],
                'speed': 0.2,
                'loop': False
            },
            'sleeping': {
                'frames': ['🐭💤', '🐹💤', '😴', '💤'],
                'speed': 2.0,
                'loop': True
            },
            'failed': {
                'frames': ['🐭😢', '🐹😢', '🐭💔', '🐹💔'],
                'speed': 0.5,
                'loop': False
            },
            'thinking': {
                'frames': ['🐭🤔', '🐹🤔', '🐭💭', '🐹💭'],
                'speed': 0.8,
                'loop': True
            }
        }
        
        # 加载GIF动画（如果存在）
        self.gif_animations = {}
        self.load_gif_animations()
        
        # 当前动画状态
        self.current_animation = 'idle'
        self.animation_start_time = time.time()
    
    def load_gif_animations(self):
        """加载GIF动画文件"""
        if not os.path.exists(self.gif_dir):
            os.makedirs(self.gif_dir, exist_ok=True)
            return
        
        # 扫描目录中的所有GIF文件
        gif_files = [f for f in os.listdir(self.gif_dir) if f.endswith('.gif')]
        
        # 按类型分组GIF文件
        animation_groups = {
            'idle': [],      # 待机动画 - daiji开头
            'stealing': [],  # 偷吃动画 - touchi开头  
            'interaction': [] # 互动动画 - hudong开头
        }
        
        # 分类GIF文件
        for gif_file in gif_files:
            if gif_file.startswith('daiji'):
                animation_groups['idle'].append(gif_file)
            elif gif_file.startswith('touchi'):
                animation_groups['stealing'].append(gif_file)
            elif gif_file.startswith('hudong'):
                animation_groups['interaction'].append(gif_file)
        
        # 为每种动画类型加载所有相关的GIF文件
        for animation_type, file_list in animation_groups.items():
            if file_list:
                # 对文件进行排序以确保一致的加载顺序
                file_list.sort()
                all_frames = []
                
                for gif_file in file_list:
                    gif_path = os.path.join(self.gif_dir, gif_file)
                    try:
                        frames = self.load_gif_frames(gif_path)
                        all_frames.extend(frames)
                        print(f"成功加载 {animation_type} 动画: {gif_file} ({len(frames)} 帧)")
                    except Exception as e:
                        print(f"加载GIF失败 {gif_path}: {e}")
                
                if all_frames:
                    self.gif_animations[animation_type] = all_frames
                    print(f"{animation_type} 动画总共加载了 {len(all_frames)} 帧")
        
        # 兼容旧的动画名称映射
        if 'interaction' in self.gif_animations:
            self.gif_animations['celebrating'] = self.gif_animations['interaction']
            self.gif_animations['thinking'] = self.gif_animations['interaction']
    
    def load_gif_frames(self, gif_path: str) -> List[ImageTk.PhotoImage]:
        """加载GIF的所有帧"""
        frames = []
        try:
            with Image.open(gif_path) as img:
                # 获取GIF的所有帧
                frame_count = 0
                while True:
                    try:
                        img.seek(frame_count)
                        # 调整大小（缩小偷吃图片）
                        frame = img.copy().convert('RGBA')
                        frame.thumbnail((100, 100), Image.LANCZOS)
                        
                        # 转换为PhotoImage
                        photo = ImageTk.PhotoImage(frame)
                        frames.append(photo)
                        frame_count += 1
                    except EOFError:
                        break
        except Exception as e:
            print(f"处理GIF帧时出错: {e}")
        
        return frames
    
    def set_animation(self, animation_type: str):
        """设置当前动画"""
        if animation_type in self.animations:
            self.current_animation = animation_type
            self.current_frame = 0
            self.animation_start_time = time.time()
    
    def get_current_frame(self, animation_type: Optional[str] = None) -> str:
        """获取当前动画帧"""
        if animation_type and animation_type != self.current_animation:
            self.set_animation(animation_type)
        
        current_time = time.time()
        animation_config = self.animations.get(self.current_animation, self.animations['idle'])
        
        # 检查是否需要更新帧
        frame_duration = animation_config['speed']
        if current_time - self.last_frame_time >= frame_duration:
            self.last_frame_time = current_time
            
            frames = animation_config['frames']
            if animation_config['loop']:
                self.current_frame = (self.current_frame + 1) % len(frames)
            else:
                if self.current_frame < len(frames) - 1:
                    self.current_frame += 1
                else:
                    # 非循环动画结束后回到idle
                    if self.current_animation != 'idle':
                        self.set_animation('idle')
        
        # 返回当前帧
        animation_config = self.animations.get(self.current_animation, self.animations['idle'])
        frames = animation_config['frames']
        return frames[self.current_frame]
    
    def get_gif_frame(self, animation_type: str) -> Optional[ImageTk.PhotoImage]:
        """获取GIF动画帧"""
        if animation_type not in self.gif_animations:
            print(f"警告: 动画类型 '{animation_type}' 不存在于gif_animations中")
            return None
        
        frames = self.gif_animations[animation_type]
        if not frames:
            print(f"警告: 动画类型 '{animation_type}' 没有加载任何帧")
            return None
        
        # 添加调试信息
        if animation_type == 'stealing':
            print(f"偷吃动画帧数: {len(frames)}")
        
        # 计算当前帧索引
        current_time = time.time()
        elapsed = current_time - self.animation_start_time
        frame_duration = 0.1  # GIF帧持续时间
        
        # 计算总的动画周期（所有帧播放一遍的时间）
        total_cycle_time = len(frames) * frame_duration
        
        # 计算当前是第几个循环周期
        current_cycle = int(elapsed / total_cycle_time)
        
        # 对于偷吃动画，持续循环touchi GIF，不切换
        if animation_type == 'stealing':
            # 偷吃动画无限循环，不重置
            pass
        else:
            # 其他动画按原逻辑处理
            if current_cycle >= self.max_loops:
                self.animation_start_time = current_time
                elapsed = 0
                current_cycle = 0
        
        # 计算当前帧索引
        frame_index = int(elapsed / frame_duration) % len(frames)
        
        return frames[frame_index]
    
    def get_random_idle_animation(self) -> str:
        """获取随机的待机动画"""
        idle_variations = [
            '🐭', '🐹', '🐭😊', '🐹😊', '🐭🌟', '🐹🌟',
            '🐭💫', '🐹💫', '🐭🎵', '🐹🎵'
        ]
        return random.choice(idle_variations)
    
    def get_emotion_animation(self, emotion: str) -> str:
        """根据情绪获取动画"""
        emotion_map = {
            'happy': '🐭😄',
            'sad': '🐭😢',
            'excited': '🐭🤩',
            'tired': '🐭😴',
            'angry': '🐭😠',
            'surprised': '🐭😲',
            'love': '🐭😍',
            'cool': '🐭😎'
        }
        return emotion_map.get(emotion, '🐭')
    
    def create_text_animation(self, text: str, duration: float = 2.0) -> Dict:
        """创建文本动画效果"""
        return {
            'type': 'text',
            'content': text,
            'duration': duration,
            'start_time': time.time(),
            'effects': ['fade_in', 'bounce']
        }
    
    def get_seasonal_animation(self) -> str:
        """获取季节性动画"""
        import datetime
        now = datetime.datetime.now()
        month = now.month
        
        if month in [12, 1, 2]:  # 冬季
            return '🐭❄️'
        elif month in [3, 4, 5]:  # 春季
            return '🐭🌸'
        elif month in [6, 7, 8]:  # 夏季
            return '🐭☀️'
        else:  # 秋季
            return '🐭🍂'
    
    def get_time_based_animation(self) -> str:
        """根据时间获取动画"""
        import datetime
        now = datetime.datetime.now()
        hour = now.hour
        
        if 6 <= hour < 12:  # 早晨
            return '🐭🌅'
        elif 12 <= hour < 18:  # 下午
            return '🐭☀️'
        elif 18 <= hour < 22:  # 傍晚
            return '🐭🌆'
        else:  # 夜晚
            return '🐭🌙'
    
    def create_particle_effect(self, effect_type: str) -> Dict:
        """创建粒子效果"""
        effects = {
            'sparkle': {
                'particles': ['✨', '⭐', '💫', '🌟'],
                'count': 5,
                'duration': 1.0
            },
            'money': {
                'particles': ['💰', '💎', '🪙', '💵'],
                'count': 3,
                'duration': 1.5
            },
            'hearts': {
                'particles': ['💖', '💕', '💗', '💝'],
                'count': 4,
                'duration': 2.0
            },
            'explosion': {
                'particles': ['💥', '🎆', '🎇', '✨'],
                'count': 8,
                'duration': 0.8
            }
        }
        
        return effects.get(effect_type, effects['sparkle'])
    
    def get_combo_animation(self, combo_count: int) -> str:
        """根据连击数获取动画"""
        if combo_count >= 10:
            return '🐭🔥🔥🔥'  # 超级连击
        elif combo_count >= 5:
            return '🐭🔥🔥'    # 大连击
        elif combo_count >= 3:
            return '🐭🔥'      # 连击
        else:
            return '🐭'        # 普通
    
    def get_rarity_animation(self, rarity: str) -> str:
        """根据物品稀有度获取动画"""
        rarity_animations = {
            'red': '🐭🔴✨',     # 红色传说
            'gold': '🐭🟡⭐',    # 金色史诗
            'purple': '🐭🟣💜',  # 紫色稀有
            'blue': '🐭🔵💙'     # 蓝色普通
        }
        return rarity_animations.get(rarity, '🐭')
    
    def create_floating_text(self, text: str, color: str = 'white') -> Dict:
        """创建浮动文本效果"""
        return {
            'type': 'floating_text',
            'text': text,
            'color': color,
            'start_time': time.time(),
            'duration': 2.0,
            'start_y': 0,
            'end_y': -50,
            'fade_out': True
        }
    
    def update_animation_speed(self, speed_multiplier: float):
        """更新动画速度"""
        self.animation_speed = max(0.1, min(2.0, speed_multiplier))
        
        # 更新所有动画的速度
        for animation in self.animations.values():
            animation['speed'] *= speed_multiplier
    
    def reset_animation(self):
        """重置动画状态"""
        self.current_animation = 'idle'
        self.current_frame = 0
        self.animation_start_time = time.time()
        self.last_frame_time = time.time()
    
    def get_status_indicator(self, status: str) -> str:
        """获取状态指示器"""
        indicators = {
            'online': '🟢',
            'busy': '🟡',
            'away': '🟠',
            'offline': '🔴',
            'sleeping': '💤',
            'working': '⚡',
            'happy': '😊',
            'sad': '😢'
        }
        return indicators.get(status, '⚪')
    
    def create_achievement_animation(self, achievement_name: str) -> Dict:
        """创建成就动画"""
        return {
            'type': 'achievement',
            'name': achievement_name,
            'icon': '🏆',
            'duration': 3.0,
            'start_time': time.time(),
            'effects': ['slide_in', 'glow', 'slide_out']
        }
    
    def get_weather_animation(self, weather: str) -> str:
        """根据天气获取动画"""
        weather_animations = {
            'sunny': '🐭☀️',
            'cloudy': '🐭☁️',
            'rainy': '🐭🌧️',
            'snowy': '🐭❄️',
            'stormy': '🐭⛈️',
            'windy': '🐭💨'
        }
        return weather_animations.get(weather, '🐭')
    
    def stop(self):
        """停止动画"""
        try:
            # 停止当前动画
            self.current_animation = 'idle'
            self.current_frame = 0
            
            # 清理资源
            self.cleanup()
            
        except Exception as e:
            print(f"停止动画时出错: {e}")
    
    def cleanup(self):
        """清理资源"""
        # 清理GIF动画资源
        for animation_frames in self.gif_animations.values():
            for frame in animation_frames:
                try:
                    # PhotoImage对象会自动清理
                    pass
                except:
                    pass
        
        self.gif_animations.clear()