#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
桌面宠物数据管理模块
处理用户数据的保存、加载和管理
"""

import os
import json
import sqlite3
import datetime
import threading
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path

@dataclass
class StealRecord:
    """偷吃记录"""
    timestamp: str
    success: bool
    items_count: int
    total_value: float
    items: List[Dict[str, Any]]
    combo_count: int = 0
    bonus_multiplier: float = 1.0

@dataclass
class Achievement:
    """成就"""
    id: str
    name: str
    description: str
    unlocked: bool = False
    unlock_time: Optional[str] = None
    progress: float = 0.0
    max_progress: float = 100.0

@dataclass
class DailyStats:
    """每日统计"""
    date: str
    steal_count: int = 0
    success_count: int = 0
    total_value: float = 0.0
    max_combo: int = 0
    items_obtained: int = 0

class PetDataManager:
    """桌面宠物数据管理器"""
    
    def __init__(self, data_dir: Optional[str] = None):
        if data_dir is None:
            data_dir = os.path.join(os.path.dirname(__file__), 'data')
        
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        # 数据文件路径
        self.user_data_file = self.data_dir / 'user_data.json'
        self.history_db_file = self.data_dir / 'history.db'
        self.achievements_file = self.data_dir / 'achievements.json'
        self.stats_file = self.data_dir / 'stats.json'
        
        # 线程锁
        self._lock = threading.Lock()
        
        # 初始化数据
        self.user_data = self.load_user_data()
        self.achievements = self.load_achievements()
        self.init_database()
    
    def init_database(self):
        """初始化SQLite数据库"""
        try:
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            # 创建偷吃历史表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS steal_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    success BOOLEAN NOT NULL,
                    items_count INTEGER NOT NULL,
                    total_value REAL NOT NULL,
                    items TEXT NOT NULL,
                    combo_count INTEGER DEFAULT 0,
                    bonus_multiplier REAL DEFAULT 1.0
                )
            ''')
            
            # 创建每日统计表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS daily_stats (
                    date TEXT PRIMARY KEY,
                    steal_count INTEGER DEFAULT 0,
                    success_count INTEGER DEFAULT 0,
                    total_value REAL DEFAULT 0.0,
                    max_combo INTEGER DEFAULT 0,
                    items_obtained INTEGER DEFAULT 0
                )
            ''')
            
            # 创建物品统计表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS item_stats (
                    item_name TEXT PRIMARY KEY,
                    obtained_count INTEGER DEFAULT 0,
                    total_value REAL DEFAULT 0.0,
                    first_obtained TEXT,
                    last_obtained TEXT
                )
            ''')
            
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"初始化数据库失败: {e}")
    
    def load_user_data(self) -> Dict[str, Any]:
        """加载用户数据"""
        default_data = {
            'total_steals': 0,
            'successful_steals': 0,
            'total_value': 0.0,
            'current_combo': 0,
            'max_combo': 0,
            'last_steal_time': None,
            'level': 1,
            'experience': 0,
            'inventory': {},
            'settings': {
                'auto_steal_enabled': False,
                'notifications_enabled': True,
                'sound_enabled': True
            },
            'statistics': {
                'play_time': 0,
                'days_played': 0,
                'favorite_items': [],
                'lucky_streaks': 0
            }
        }
        
        try:
            if self.user_data_file.exists():
                with open(self.user_data_file, 'r', encoding='utf-8') as f:
                    loaded_data = json.load(f)
                    # 合并默认数据和加载的数据
                    return {**default_data, **loaded_data}
            else:
                return default_data
        except Exception as e:
            print(f"加载用户数据失败: {e}")
            return default_data
    
    def save_user_data(self):
        """保存用户数据"""
        try:
            with self._lock:
                with open(self.user_data_file, 'w', encoding='utf-8') as f:
                    json.dump(self.user_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存用户数据失败: {e}")
    
    def load_achievements(self) -> List[Achievement]:
        """加载成就数据"""
        default_achievements = [
            Achievement('first_steal', '初次偷吃', '完成第一次偷吃', max_progress=1),
            Achievement('steal_10', '小偷新手', '成功偷吃10次', max_progress=10),
            Achievement('steal_100', '偷吃大师', '成功偷吃100次', max_progress=100),
            Achievement('steal_1000', '传奇大盗', '成功偷吃1000次', max_progress=1000),
            Achievement('combo_5', '连击新手', '达成5连击', max_progress=5),
            Achievement('combo_20', '连击高手', '达成20连击', max_progress=20),
            Achievement('combo_50', '连击大师', '达成50连击', max_progress=50),
            Achievement('value_1000', '财富积累者', '累计获得价值1000', max_progress=1000),
            Achievement('value_10000', '富翁', '累计获得价值10000', max_progress=10000),
            Achievement('daily_10', '勤奋偷吃者', '单日偷吃10次', max_progress=10),
            Achievement('lucky_day', '幸运日', '单日成功率100%（至少5次）', max_progress=5),
            Achievement('collector', '收藏家', '收集50种不同物品', max_progress=50),
            Achievement('speed_demon', '速度恶魔', '1分钟内完成3次偷吃', max_progress=3),
            Achievement('night_owl', '夜猫子', '在凌晨2-6点偷吃', max_progress=1),
            Achievement('early_bird', '早起鸟', '在早晨6-8点偷吃', max_progress=1)
        ]
        
        try:
            if self.achievements_file.exists():
                with open(self.achievements_file, 'r', encoding='utf-8') as f:
                    loaded_data = json.load(f)
                    achievements = []
                    
                    # 将加载的数据转换为Achievement对象
                    for item in loaded_data:
                        achievement = Achievement(**item)
                        achievements.append(achievement)
                    
                    # 添加新的默认成就（如果不存在）
                    existing_ids = {a.id for a in achievements}
                    for default_achievement in default_achievements:
                        if default_achievement.id not in existing_ids:
                            achievements.append(default_achievement)
                    
                    return achievements
            else:
                return default_achievements
        except Exception as e:
            print(f"加载成就数据失败: {e}")
            return default_achievements
    
    def save_achievements(self):
        """保存成就数据"""
        try:
            with self._lock:
                data = [asdict(achievement) for achievement in self.achievements]
                with open(self.achievements_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存成就数据失败: {e}")
    
    def add_steal_record(self, record: StealRecord):
        """添加偷吃记录"""
        try:
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO steal_history 
                (timestamp, success, items_count, total_value, items, combo_count, bonus_multiplier)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                record.timestamp,
                record.success,
                record.items_count,
                record.total_value,
                json.dumps(record.items, ensure_ascii=False),
                record.combo_count,
                record.bonus_multiplier
            ))
            
            conn.commit()
            conn.close()
            
            # 更新用户数据
            self.update_user_stats(record)
            
            # 更新每日统计
            self.update_daily_stats(record)
            
            # 更新物品统计
            self.update_item_stats(record)
            
            # 检查成就
            self.check_achievements(record)
            
        except Exception as e:
            print(f"添加偷吃记录失败: {e}")
    
    def update_user_stats(self, record: StealRecord):
        """更新用户统计数据"""
        with self._lock:
            self.user_data['total_steals'] += 1
            
            if record.success:
                self.user_data['successful_steals'] += 1
                self.user_data['total_value'] += record.total_value
                self.user_data['current_combo'] = record.combo_count
                self.user_data['max_combo'] = max(
                    self.user_data['max_combo'], 
                    record.combo_count
                )
                
                # 更新经验值
                exp_gain = int(record.total_value * 0.1) + record.items_count
                self.user_data['experience'] += exp_gain
                
                # 检查升级
                self.check_level_up()
                
                # 更新库存
                for item in record.items:
                    item_name = item.get('name', '未知物品')
                    if item_name in self.user_data['inventory']:
                        self.user_data['inventory'][item_name] += 1
                    else:
                        self.user_data['inventory'][item_name] = 1
            else:
                self.user_data['current_combo'] = 0
            
            self.user_data['last_steal_time'] = record.timestamp
            self.save_user_data()
    
    def check_level_up(self):
        """检查是否升级"""
        current_level = self.user_data['level']
        current_exp = self.user_data['experience']
        
        # 计算升级所需经验（每级需要的经验递增）
        required_exp = current_level * 100 + (current_level - 1) * 50
        
        if current_exp >= required_exp:
            self.user_data['level'] += 1
            self.user_data['experience'] -= required_exp
            return True
        return False
    
    def update_daily_stats(self, record: StealRecord):
        """更新每日统计"""
        try:
            today = datetime.datetime.now().strftime('%Y-%m-%d')
            
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            # 获取今日统计
            cursor.execute('SELECT * FROM daily_stats WHERE date = ?', (today,))
            row = cursor.fetchone()
            
            if row:
                # 更新现有记录
                steal_count = row[1] + 1
                success_count = row[2] + (1 if record.success else 0)
                total_value = row[3] + (record.total_value if record.success else 0)
                max_combo = max(row[4], record.combo_count)
                items_obtained = row[5] + (record.items_count if record.success else 0)
                
                cursor.execute('''
                    UPDATE daily_stats 
                    SET steal_count = ?, success_count = ?, total_value = ?, 
                        max_combo = ?, items_obtained = ?
                    WHERE date = ?
                ''', (steal_count, success_count, total_value, max_combo, items_obtained, today))
            else:
                # 创建新记录
                cursor.execute('''
                    INSERT INTO daily_stats 
                    (date, steal_count, success_count, total_value, max_combo, items_obtained)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    today, 1, 
                    1 if record.success else 0,
                    record.total_value if record.success else 0,
                    record.combo_count,
                    record.items_count if record.success else 0
                ))
            
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"更新每日统计失败: {e}")
    
    def update_item_stats(self, record: StealRecord):
        """更新物品统计"""
        if not record.success:
            return
        
        try:
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            for item in record.items:
                item_name = item.get('name', '未知物品')
                item_value = item.get('value', 0)
                
                # 检查物品是否已存在
                cursor.execute('SELECT * FROM item_stats WHERE item_name = ?', (item_name,))
                row = cursor.fetchone()
                
                if row:
                    # 更新现有记录
                    cursor.execute('''
                        UPDATE item_stats 
                        SET obtained_count = obtained_count + 1,
                            total_value = total_value + ?,
                            last_obtained = ?
                        WHERE item_name = ?
                    ''', (item_value, record.timestamp, item_name))
                else:
                    # 创建新记录
                    cursor.execute('''
                        INSERT INTO item_stats 
                        (item_name, obtained_count, total_value, first_obtained, last_obtained)
                        VALUES (?, 1, ?, ?, ?)
                    ''', (item_name, item_value, record.timestamp, record.timestamp))
            
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"更新物品统计失败: {e}")
    
    def check_achievements(self, record: StealRecord):
        """检查并解锁成就"""
        updated = False
        
        for achievement in self.achievements:
            if achievement.unlocked:
                continue
            
            # 检查各种成就条件
            if achievement.id == 'first_steal' and self.user_data['total_steals'] >= 1:
                self.unlock_achievement(achievement)
                updated = True
            
            elif achievement.id == 'steal_10' and self.user_data['successful_steals'] >= 10:
                self.unlock_achievement(achievement)
                updated = True
            
            elif achievement.id == 'steal_100' and self.user_data['successful_steals'] >= 100:
                self.unlock_achievement(achievement)
                updated = True
            
            elif achievement.id == 'steal_1000' and self.user_data['successful_steals'] >= 1000:
                self.unlock_achievement(achievement)
                updated = True
            
            elif achievement.id == 'combo_5' and self.user_data['max_combo'] >= 5:
                self.unlock_achievement(achievement)
                updated = True
            
            elif achievement.id == 'combo_20' and self.user_data['max_combo'] >= 20:
                self.unlock_achievement(achievement)
                updated = True
            
            elif achievement.id == 'combo_50' and self.user_data['max_combo'] >= 50:
                self.unlock_achievement(achievement)
                updated = True
            
            elif achievement.id == 'value_1000' and self.user_data['total_value'] >= 1000:
                self.unlock_achievement(achievement)
                updated = True
            
            elif achievement.id == 'value_10000' and self.user_data['total_value'] >= 10000:
                self.unlock_achievement(achievement)
                updated = True
            
            # 检查每日成就
            elif achievement.id in ['daily_10', 'lucky_day']:
                self.check_daily_achievements(achievement)
                updated = True
            
            # 检查收藏家成就
            elif achievement.id == 'collector':
                unique_items = len(self.user_data['inventory'])
                if unique_items >= 50:
                    self.unlock_achievement(achievement)
                    updated = True
                else:
                    achievement.progress = unique_items
            
            # 检查时间相关成就
            elif achievement.id in ['night_owl', 'early_bird']:
                self.check_time_achievements(achievement, record)
                updated = True
        
        if updated:
            self.save_achievements()
    
    def unlock_achievement(self, achievement: Achievement):
        """解锁成就"""
        achievement.unlocked = True
        achievement.unlock_time = datetime.datetime.now().isoformat()
        achievement.progress = achievement.max_progress
        print(f"🏆 成就解锁: {achievement.name} - {achievement.description}")
    
    def check_daily_achievements(self, achievement: Achievement):
        """检查每日成就"""
        try:
            today = datetime.datetime.now().strftime('%Y-%m-%d')
            
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            cursor.execute('SELECT * FROM daily_stats WHERE date = ?', (today,))
            row = cursor.fetchone()
            
            if row:
                if achievement.id == 'daily_10' and row[1] >= 10:  # steal_count
                    self.unlock_achievement(achievement)
                elif achievement.id == 'lucky_day' and row[1] >= 5 and row[2] == row[1]:  # 100%成功率
                    self.unlock_achievement(achievement)
            
            conn.close()
        except Exception as e:
            print(f"检查每日成就失败: {e}")
    
    def check_time_achievements(self, achievement: Achievement, record: StealRecord):
        """检查时间相关成就"""
        try:
            steal_time = datetime.datetime.fromisoformat(record.timestamp)
            hour = steal_time.hour
            
            if achievement.id == 'night_owl' and 2 <= hour < 6:
                self.unlock_achievement(achievement)
            elif achievement.id == 'early_bird' and 6 <= hour < 8:
                self.unlock_achievement(achievement)
        except Exception as e:
            print(f"检查时间成就失败: {e}")
    
    def get_steal_history(self, limit: int = 100) -> List[StealRecord]:
        """获取偷吃历史"""
        try:
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT timestamp, success, items_count, total_value, items, combo_count, bonus_multiplier
                FROM steal_history 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (limit,))
            
            records = []
            for row in cursor.fetchall():
                record = StealRecord(
                    timestamp=row[0],
                    success=bool(row[1]),
                    items_count=row[2],
                    total_value=row[3],
                    items=json.loads(row[4]),
                    combo_count=row[5],
                    bonus_multiplier=row[6]
                )
                records.append(record)
            
            conn.close()
            return records
        except Exception as e:
            print(f"获取偷吃历史失败: {e}")
            return []
    
    def get_daily_stats(self, days: int = 30) -> List[DailyStats]:
        """获取每日统计"""
        try:
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT date, steal_count, success_count, total_value, max_combo, items_obtained
                FROM daily_stats 
                ORDER BY date DESC 
                LIMIT ?
            ''', (days,))
            
            stats = []
            for row in cursor.fetchall():
                stat = DailyStats(
                    date=row[0],
                    steal_count=row[1],
                    success_count=row[2],
                    total_value=row[3],
                    max_combo=row[4],
                    items_obtained=row[5]
                )
                stats.append(stat)
            
            conn.close()
            return stats
        except Exception as e:
            print(f"获取每日统计失败: {e}")
            return []
    
    def get_item_stats(self) -> List[Dict[str, Any]]:
        """获取物品统计"""
        try:
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT item_name, obtained_count, total_value, first_obtained, last_obtained
                FROM item_stats 
                ORDER BY obtained_count DESC
            ''')
            
            stats = []
            for row in cursor.fetchall():
                stat = {
                    'name': row[0],
                    'count': row[1],
                    'total_value': row[2],
                    'first_obtained': row[3],
                    'last_obtained': row[4]
                }
                stats.append(stat)
            
            conn.close()
            return stats
        except Exception as e:
            print(f"获取物品统计失败: {e}")
            return []
    
    def export_data(self, file_path: str) -> bool:
        """导出所有数据"""
        try:
            export_data = {
                'user_data': self.user_data,
                'achievements': [asdict(a) for a in self.achievements],
                'steal_history': [asdict(r) for r in self.get_steal_history(1000)],
                'daily_stats': [asdict(s) for s in self.get_daily_stats(365)],
                'item_stats': self.get_item_stats(),
                'export_time': datetime.datetime.now().isoformat()
            }
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            return True
        except Exception as e:
            print(f"导出数据失败: {e}")
            return False
    
    def reset_all_data(self):
        """重置所有数据"""
        try:
            # 重置用户数据
            self.user_data = self.load_user_data()
            self.save_user_data()
            
            # 重置成就
            for achievement in self.achievements:
                achievement.unlocked = False
                achievement.unlock_time = None
                achievement.progress = 0.0
            self.save_achievements()
            
            # 清空数据库
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM steal_history')
            cursor.execute('DELETE FROM daily_stats')
            cursor.execute('DELETE FROM item_stats')
            
            conn.commit()
            conn.close()
            
            print("所有数据已重置")
        except Exception as e:
            print(f"重置数据失败: {e}")
    
    def cleanup_old_data(self, days: int = 365):
        """清理旧数据"""
        try:
            cutoff_date = (datetime.datetime.now() - datetime.timedelta(days=days)).strftime('%Y-%m-%d')
            
            conn = sqlite3.connect(str(self.history_db_file))
            cursor = conn.cursor()
            
            # 删除旧的偷吃记录
            cursor.execute('DELETE FROM steal_history WHERE timestamp < ?', (cutoff_date,))
            
            # 删除旧的每日统计
            cursor.execute('DELETE FROM daily_stats WHERE date < ?', (cutoff_date,))
            
            conn.commit()
            conn.close()
            
            print(f"已清理{days}天前的数据")
        except Exception as e:
            print(f"清理旧数据失败: {e}")
    
    def get_summary_stats(self) -> Dict[str, Any]:
        """获取汇总统计信息"""
        return {
            'user_level': self.user_data['level'],
            'total_steals': self.user_data['total_steals'],
            'successful_steals': self.user_data['successful_steals'],
            'success_rate': (self.user_data['successful_steals'] / max(1, self.user_data['total_steals'])) * 100,
            'total_value': self.user_data['total_value'],
            'max_combo': self.user_data['max_combo'],
            'current_combo': self.user_data['current_combo'],
            'unique_items': len(self.user_data['inventory']),
            'total_items': sum(self.user_data['inventory'].values()),
            'achievements_unlocked': len([a for a in self.achievements if a.unlocked]),
            'total_achievements': len(self.achievements)
        }