#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
桌面宠物主程序
鼠鼠偷吃桌面宠物应用
"""

import os
import sys
import tkinter as tk
from tkinter import messagebox
import threading
import time
from pathlib import Path

# 添加当前目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

try:
    from desktop_pet import DesktopPet
    from pet_config import PetConfig
    from pet_data import PetDataManager
    from pet_utils import Logger, SystemUtils
except ImportError as e:
    print(f"导入模块失败: {e}")
    print("请确保所有必要的文件都在同一目录下")
    sys.exit(1)

class PetApplication:
    """桌面宠物应用主类"""
    
    def __init__(self):
        self.app_dir = Path(__file__).parent
        self.config = None
        self.data_manager = None
        self.logger = None
        self.pet = None
        self.root = None
        
        # 初始化应用
        self.init_application()
    
    def init_application(self):
        """初始化应用"""
        try:
            # 创建必要的目录
            self.create_directories()
            
            # 初始化日志
            log_file = self.app_dir / 'logs' / 'pet.log'
            self.logger = Logger(str(log_file), level='INFO')
            self.logger.info("桌面宠物应用启动")
            
            # 初始化配置
            config_file = self.app_dir / 'pet_config.json'
            self.config = PetConfig(str(config_file))
            self.logger.info("配置加载完成")
            
            # 初始化数据管理器
            data_dir = self.app_dir / 'data'
            self.data_manager = PetDataManager(str(data_dir))
            self.logger.info("数据管理器初始化完成")
            
            # 检查系统要求
            if not self.check_system_requirements():
                return False
            
            # 创建主窗口
            self.create_main_window()
            
            return True
            
        except Exception as e:
            error_msg = f"应用初始化失败: {e}"
            print(error_msg)
            if self.logger:
                self.logger.error(error_msg)
            messagebox.showerror("错误", error_msg)
            return False
    
    def create_directories(self):
        """创建必要的目录"""
        directories = [
            'data',
            'logs',
            'cache',
            'backups',
            'biqoqinggif',  # GIF动画目录
            'sounds',       # 音效目录
            'themes'        # 主题目录
        ]
        
        for directory in directories:
            dir_path = self.app_dir / directory
            dir_path.mkdir(exist_ok=True)
    
    def check_system_requirements(self) -> bool:
        """检查系统要求"""
        try:
            # 检查Python版本
            if sys.version_info < (3, 7):
                messagebox.showerror(
                    "系统要求不满足", 
                    "需要Python 3.7或更高版本\n当前版本: {}.{}.{}".format(*sys.version_info[:3])
                )
                return False
            
            # 检查必要的库
            required_modules = ['tkinter', 'PIL', 'sqlite3', 'json']
            missing_modules = []
            
            for module in required_modules:
                try:
                    __import__(module)
                except ImportError:
                    missing_modules.append(module)
            
            if missing_modules:
                messagebox.showerror(
                    "缺少必要模块", 
                    f"缺少以下模块: {', '.join(missing_modules)}\n请安装后重试"
                )
                return False
            
            # 检查磁盘空间（至少100MB）
            import shutil
            free_space = shutil.disk_usage(self.app_dir).free
            if free_space < 100 * 1024 * 1024:  # 100MB
                messagebox.showwarning(
                    "磁盘空间不足", 
                    "可用磁盘空间不足100MB，可能影响应用运行"
                )
            
            self.logger.info("系统要求检查通过")
            return True
            
        except Exception as e:
            self.logger.error(f"系统要求检查失败: {e}")
            return False
    
    def create_main_window(self):
        """创建主窗口"""
        try:
            # 创建根窗口
            self.root = tk.Tk()
            self.root.title("鼠鼠偷吃桌面宠物")
            
            # 设置窗口图标（如果存在）
            icon_path = self.app_dir / 'icon.ico'
            if icon_path.exists():
                self.root.iconbitmap(str(icon_path))
            
            # 应用配置
            self.apply_window_config()
            
            # 创建桌面宠物
            self.pet = DesktopPet(
                self.root, 
                self.config, 
                self.data_manager, 
                self.logger
            )
            
            # 设置关闭事件
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            
            # 绑定全局快捷键
            self.setup_hotkeys()
            
            self.logger.info("主窗口创建完成")
            
        except Exception as e:
            error_msg = f"创建主窗口失败: {e}"
            self.logger.error(error_msg)
            messagebox.showerror("错误", error_msg)
            raise
    
    def apply_window_config(self):
        """应用窗口配置"""
        try:
            # 窗口大小
            width = self.config.window_width
            height = self.config.window_height
            
            # 窗口位置
            start_position = self.config.get('window.start_position', 'center')
            
            if start_position == 'center':
                screen_width = self.root.winfo_screenwidth()
                screen_height = self.root.winfo_screenheight()
                x = (screen_width - width) // 2
                y = (screen_height - height) // 2
            elif start_position == 'top_left':
                x, y = 50, 50
            elif start_position == 'top_right':
                screen_width = self.root.winfo_screenwidth()
                x = screen_width - width - 50
                y = 50
            elif start_position == 'bottom_left':
                screen_height = self.root.winfo_screenheight()
                x = 50
                y = screen_height - height - 100
            elif start_position == 'bottom_right':
                screen_width = self.root.winfo_screenwidth()
                screen_height = self.root.winfo_screenheight()
                x = screen_width - width - 50
                y = screen_height - height - 100
            else:
                x, y = 100, 100
            
            self.root.geometry(f"{width}x{height}+{x}+{y}")
            
            # 其他窗口属性
            if self.config.always_on_top:
                self.root.attributes('-topmost', True)
            
            if self.config.borderless:
                self.root.overrideredirect(True)
            
            transparency = self.config.get('window.transparency', 0.95)
            self.root.attributes('-alpha', transparency)
            
            resizable = self.config.get('window.resizable', True)
            self.root.resizable(resizable, resizable)
            
        except Exception as e:
            self.logger.error(f"应用窗口配置失败: {e}")
    
    def setup_hotkeys(self):
        """设置全局快捷键"""
        try:
            # 获取快捷键配置
            hotkeys = self.config.get('hotkeys', {})
            
            # 这里可以添加全局快捷键支持
            # 由于tkinter的限制，这里只能绑定窗口焦点时的快捷键
            
            # 切换窗口显示/隐藏
            toggle_key = hotkeys.get('toggle_window', 'Ctrl+Shift+P')
            # self.root.bind(f'<{toggle_key}>', lambda e: self.toggle_window())
            
            # 开始偷吃
            steal_key = hotkeys.get('start_steal', 'Ctrl+S')
            self.root.bind('<Control-s>', lambda e: self.pet.start_steal() if self.pet else None)
            
            # 切换自动偷吃
            auto_key = hotkeys.get('toggle_auto', 'Ctrl+A')
            self.root.bind('<Control-a>', lambda e: self.pet.toggle_auto_steal() if self.pet else None)
            
            # 显示统计
            stats_key = hotkeys.get('show_stats', 'Ctrl+T')
            self.root.bind('<Control-t>', lambda e: self.pet.show_stats() if self.pet else None)
            
            # 设置
            settings_key = hotkeys.get('settings', 'Ctrl+comma')
            self.root.bind('<Control-comma>', lambda e: self.pet.show_settings() if self.pet else None)
            
            self.logger.info("快捷键设置完成")
            
        except Exception as e:
            self.logger.error(f"设置快捷键失败: {e}")
    
    def toggle_window(self):
        """切换窗口显示/隐藏"""
        try:
            if self.root.state() == 'withdrawn':
                self.root.deiconify()
                self.root.lift()
            else:
                self.root.withdraw()
        except Exception as e:
            self.logger.error(f"切换窗口状态失败: {e}")
    
    def on_closing(self):
        """关闭事件处理"""
        try:
            self.logger.info("应用正在关闭...")
            
            # 保存配置
            if self.config:
                self.config.save()
                self.logger.info("配置已保存")
            
            # 保存数据
            if self.data_manager:
                self.data_manager.save_user_data()
                self.data_manager.save_achievements()
                self.logger.info("数据已保存")
            
            # 停止宠物
            if self.pet:
                self.pet.stop()
                self.logger.info("宠物已停止")
            
            # 关闭窗口
            self.root.quit()
            self.root.destroy()
            
            self.logger.info("应用已关闭")
            
        except Exception as e:
            print(f"关闭应用时出错: {e}")
            if self.logger:
                self.logger.error(f"关闭应用时出错: {e}")
    
    def run(self):
        """运行应用"""
        try:
            if self.root:
                self.logger.info("开始运行主循环")
                
                # 显示启动消息
                if self.config.get('notifications.enable_notifications', True):
                    self.pet.show_notification(
                        "桌面宠物启动", 
                        "鼠鼠偷吃桌面宠物已启动！", 
                        notification_type='success'
                    )
                
                # 开始主循环
                self.root.mainloop()
            else:
                self.logger.error("主窗口未创建，无法运行")
                
        except KeyboardInterrupt:
            self.logger.info("收到中断信号，正在关闭...")
            self.on_closing()
        except Exception as e:
            error_msg = f"运行应用时出错: {e}"
            self.logger.error(error_msg)
            messagebox.showerror("运行错误", error_msg)
    
    def restart(self):
        """重启应用"""
        try:
            self.logger.info("重启应用")
            
            # 保存当前状态
            if self.config:
                self.config.save()
            if self.data_manager:
                self.data_manager.save_user_data()
                self.data_manager.save_achievements()
            
            # 关闭当前实例
            if self.root:
                self.root.quit()
                self.root.destroy()
            
            # 重新启动
            os.execv(sys.executable, ['python'] + sys.argv)
            
        except Exception as e:
            self.logger.error(f"重启应用失败: {e}")
            messagebox.showerror("重启失败", f"重启应用失败: {e}")

def check_single_instance():
    """检查是否已有实例在运行"""
    try:
        import fcntl
        lock_file = '/tmp/desktop_pet.lock'
        
        # 尝试创建锁文件
        lock_fd = os.open(lock_file, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        
        try:
            # 尝试获取排他锁
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except IOError:
            # 锁已被占用，说明有其他实例在运行
            os.close(lock_fd)
            return False
            
    except ImportError:
        # Windows系统或fcntl不可用
        return True
    except Exception:
        return True

def show_splash_screen():
    """显示启动画面"""
    try:
        splash = tk.Tk()
        splash.title("桌面宠物")
        splash.geometry("400x300")
        splash.resizable(False, False)
        
        # 居中显示
        splash.eval('tk::PlaceWindow . center')
        
        # 移除标题栏
        splash.overrideredirect(True)
        
        # 设置背景
        splash.configure(bg='#f0f0f0')
        
        # 添加标题
        title_label = tk.Label(
            splash, 
            text="🐭 鼠鼠偷吃桌面宠物", 
            font=('Arial', 20, 'bold'),
            bg='#f0f0f0',
            fg='#333333'
        )
        title_label.pack(pady=50)
        
        # 添加版本信息
        version_label = tk.Label(
            splash, 
            text="版本 1.0.0", 
            font=('Arial', 12),
            bg='#f0f0f0',
            fg='#666666'
        )
        version_label.pack()
        
        # 添加加载信息
        loading_label = tk.Label(
            splash, 
            text="正在加载...", 
            font=('Arial', 10),
            bg='#f0f0f0',
            fg='#888888'
        )
        loading_label.pack(pady=30)
        
        # 添加进度条（简单的文本动画）
        progress_var = tk.StringVar()
        progress_label = tk.Label(
            splash, 
            textvariable=progress_var,
            font=('Arial', 12),
            bg='#f0f0f0',
            fg='#4CAF50'
        )
        progress_label.pack(pady=10)
        
        # 动画效果
        def animate_progress():
            for i in range(4):
                progress_var.set('●' * i + '○' * (3-i))
                splash.update()
                time.sleep(0.3)
        
        # 显示启动画面
        splash.update()
        
        # 模拟加载过程
        loading_steps = [
            "初始化配置...",
            "加载数据...",
            "准备界面...",
            "启动完成！"
        ]
        
        for step in loading_steps:
            loading_label.config(text=step)
            animate_progress()
            time.sleep(0.5)
        
        # 关闭启动画面
        splash.destroy()
        
    except Exception as e:
        print(f"显示启动画面失败: {e}")

def main():
    """主函数"""
    try:
        print("🐭 鼠鼠偷吃桌面宠物 v1.0.0")
        print("正在启动...")
        
        # 检查单实例
        if not check_single_instance():
            print("检测到已有实例在运行")
            messagebox.showwarning("警告", "桌面宠物已在运行中！")
            return
        
        # 显示启动画面
        show_splash_screen()
        
        # 创建并运行应用
        app = PetApplication()
        if app.root:  # 确保初始化成功
            app.run()
        else:
            print("应用初始化失败")
            
    except KeyboardInterrupt:
        print("\n用户中断，正在退出...")
    except Exception as e:
        error_msg = f"应用启动失败: {e}"
        print(error_msg)
        try:
            messagebox.showerror("启动失败", error_msg)
        except:
            pass
    finally:
        print("应用已退出")

if __name__ == "__main__":
    main()